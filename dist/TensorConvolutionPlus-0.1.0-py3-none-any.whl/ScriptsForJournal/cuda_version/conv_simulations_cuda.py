#!/usr/bin/env python
import time

import torch

from utils import check_voltage_limits, check_line_current_limits, check_trafo_current_limits, tensor_convolve2d_real, \
    tensor_convolve_nd, tensor_convolve_nd_clean, tensor_convolve_nd_tf, tensor_convolve_slide_window, \
    tensor_convolve_nd_torch, tensor_convolve_nd_torch_half
from conv_simulations import get_bus_line_and_trafo_names
import pandapower as pp
import pandas as pd
from tqdm import tqdm
import numpy as np
from scipy import signal
from itertools import combinations
import string
import copy
import scipy.ndimage
from sklearn import preprocessing as pre
import tensorflow as tf
import tntorch as tn
import json
import seaborn as sns
import matplotlib.pyplot as plt

__author__ = "Demetris Chrysostomou"
__credits__ = ["Demetris Chrysostomou", "Jose Luis Rueda Torres", "Jochen Lorenz Cremer"]
__version__ = "1.0.0"
__maintainer__ = "Demetris Chrysostomou"
__email__ = "D.Chrysostomou@tudelft.nl"
__status__ = "Production"


def create_mat_dict_rest(result_dict, resolution):
    mat_dicts = {}
    axs_p = []
    axs_q = []
    keys = []
    for key in result_dict:
        tmp_dict, ax_p, ax_q = df_to_mat_tensor(result_dict[key], resolution)
        mat_dicts[key] = tmp_dict
        axs_p.append(ax_p)
        axs_q.append(ax_q)
        keys.append(key)
    combs = list(combinations(keys, len(keys) - 1))
    pq_mats = {}
    for idx, elmnt in enumerate(combs):
        pq_mat = mat_dicts[elmnt[0]]['PQ']
        for key in elmnt[1:]:
            pq_mat = signal.convolve2d(pq_mat, mat_dicts[key]['PQ'])
            pq_mat[pq_mat > 0.1] = 1
        pq_mats[keys[-idx - 1]] = pq_mat
    return pq_mats, mat_dicts, axs_p, axs_q


def create_mat_dict_rest2(result_dict, dp, dq):
    mat_dicts = {}
    axs_p = []
    axs_q = []
    keys = []
    for key in result_dict:
        # tmp_dict, ax_p, ax_q = df_to_mat_tensor2(result_dict[key], resolution, init_pq)
        tmp_dict, ax_p, ax_q = df_to_mat_tensor_scaled(result_dict[key], dp, dq)
        mat_dicts[key] = tmp_dict
        axs_p.append(ax_p)
        axs_q.append(ax_q)
        keys.append(key)
    pq_mat = mat_dicts[keys[0]]['PQ']
    for key in keys[1:]:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[key]['PQ'])
        pq_mat[pq_mat > 0.1] = 1
    return np.flipud(np.fliplr(pq_mat)), mat_dicts, axs_p, axs_q


def create_mat_dict_rest3(result_dict, dp, dq):
    mat_dicts = {}
    axs_p = []
    axs_q = []
    keys = []
    for key in result_dict:
        # tmp_dict, ax_p, ax_q = df_to_mat_tensor2(result_dict[key], resolution, init_pq)
        tmp_dict, ax_p, ax_q = df_to_mat_tensor_scaled_and_init(result_dict[key], dp, dq)
        mat_dicts[key] = tmp_dict
        axs_p.append(ax_p)
        axs_q.append(ax_q)
        keys.append(key)

    pq_mat = mat_dicts[keys[0]]['PQ']
    for key in keys[1:]:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[key]['PQ'])
        pq_mat[pq_mat > 0.1] = 1
    return np.flipud(np.fliplr(pq_mat)), mat_dicts, axs_p, axs_q


def create_mat_dict_tensor(result_dict, dp, dq, small_fsps=[]):
    mat_dicts = {}
    axs_p = []
    axs_q = []
    keys = []
    for key in result_dict:
        tmp_dict, ax_p, ax_q = df_to_mat_tensor_torch(result_dict[key], dp, dq)
        mat_dicts[key] = tmp_dict
        axs_p.append(ax_p)
        axs_q.append(ax_q)
        keys.append(key)
    i = 0
    while keys[i] in small_fsps:
        i += 1
    # pq_mat = mat_dicts[keys[0]]['PQ'].detach().cpu().numpy()
    pq_mat = mat_dicts[keys[i]]['PQ'].detach().cpu().numpy()
    for key in keys[i + 1:]:
        if key not in small_fsps:
            pq_mat = signal.convolve2d(pq_mat, mat_dicts[key]['PQ'].detach().cpu().numpy())
    unc_fa = pq_mat.copy()
    pq_mat[pq_mat > 0.1] = 1
    return np.flipud(np.fliplr(pq_mat)), mat_dicts, axs_p, axs_q, np.flipud(np.fliplr(unc_fa))


def create_mat_dict_tensorv2(result_dict, dp, dq):
    mat_dicts = {}
    axs_p = []
    axs_q = []
    keys = []
    init_ids = {}
    for key in result_dict:
        tmp_dict, ax_p, ax_q, init_ids[key] = df_to_mat_tensor_torchv2(result_dict[key], dp, dq)
        mat_dicts[key] = tmp_dict
        axs_p.append(ax_p)
        axs_q.append(ax_q)
        keys.append(key)

    pq_mat = mat_dicts[keys[0]]['PQ'].detach().cpu().numpy()
    for key in keys[1:]:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[key]['PQ'].detach().cpu().numpy())
    unc_fa = pq_mat.copy()
    pq_mat[pq_mat > 0.1] = 1
    return np.flipud(np.fliplr(pq_mat)), mat_dicts, axs_p, axs_q, np.flipud(np.fliplr(unc_fa)), init_ids


def create_mat_dict_order(result_dict, dp, dq, small_fsps=[]):
    mat_dicts = {}
    axs_p = []
    axs_q = []
    keys = []
    for key in result_dict:
        tmp_dict, ax_p, ax_q = df_to_mat_tensor_torch(result_dict[key], dp, dq)
        mat_dicts[key] = tmp_dict
        axs_p.append(ax_p)
        axs_q.append(ax_q)
        keys.append(key)
    i = 0
    while keys[i] in small_fsps:
        i += 1
    pq_mat = mat_dicts[keys[0]]['PQ'].cpu().numpy()
    for key in keys[i + 1:]:
        if key not in small_fsps:
            pq_mat = signal.convolve2d(pq_mat, mat_dicts[key]['PQ'].cpu().numpy())
    pq_mat[pq_mat > 0.1] = 1
    return np.flipud(np.fliplr(pq_mat)), mat_dicts, axs_p, axs_q, keys


def create_mat_dict_incl_delta(result_dict, dp, dq, non_lin_fsp, init_pq):
    mat_dicts = {}
    axs_p = []
    axs_q = []
    axs_p_with_delta = []
    axs_q_with_delta = []
    keys = []
    pq_non_lins = {}
    for key in result_dict:
        if key in non_lin_fsp:
            tmp_list, ax_p, ax_q, pq_non_lin = get_delta(result_dict[key], dp, dq, init_pq)
            mat_dicts[key] = tmp_list
            pq_non_lins[key] = pq_non_lin
        else:
            tmp_dict, ax_p, ax_q = df_to_mat_tensor_scaled_and_init(result_dict[key], dp, dq)
            mat_dicts[key] = tmp_dict
            axs_p.append(ax_p)
            axs_q.append(ax_q)
        axs_p_with_delta.append(ax_p)
        axs_q_with_delta.append(ax_q)
        keys.append(key)
    pq_mat = mat_dicts[keys[0]]['PQ'].cpu()
    for key in keys[1:]:
        if key not in non_lin_fsp:
            pq_mat = signal.convolve2d(pq_mat, mat_dicts[key]['PQ'].cpu().numpy())
            # pq_mat[pq_mat > 0.1] = 1
        else:
            pq_mat = signal.convolve2d(pq_mat, pq_non_lins[key].cpu().numpy())
    unc_fa = pq_mat.copy()
    pq_mat[pq_mat > 0.1] = 1
    return np.flipud(np.fliplr(pq_mat)), mat_dicts, axs_p, axs_q, axs_p_with_delta, axs_q_with_delta, np.flipud(
        np.fliplr(unc_fa))


def create_tensor_dict(result_dict, dp, dq):
    mat_dicts = {}
    axs_p = []
    axs_q = []
    keys = []
    # time_compare = {}
    for key in result_dict:
        tmp_dict, ax_p, ax_q = df_to_mat_tensor_scaled_and_init(result_dict[key], dp, dq)
        mat_dicts[key] = {k: tf.convert_to_tensor(v) for k, v in tmp_dict.items()}
        axs_p.append(ax_p)
        axs_q.append(ax_q)
        keys.append(key)
    pq_mat = mat_dicts[keys[0]]['PQ']
    # print(time_compare)
    for key in keys[1:]:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[key]['PQ'])
        pq_mat[pq_mat > 0.1] = 1
    return np.flipud(np.fliplr(pq_mat)), mat_dicts, axs_p, axs_q


def create_small_fsp_fas(prof_dict, dp, dq, init_fsp_pq):
    for idx, fsp in enumerate(prof_dict):
        if idx != 0:
            pq_mat = signal.convolve2d(pq_mat, profiles_to_mat(prof_dict[fsp], dp, dq, init_fsp_pq[fsp][0]))
            pq_mat[pq_mat > 0.1] = 1
        else:
            pq_mat = profiles_to_mat(prof_dict[fsp], dp, dq, init_fsp_pq[fsp][0])
    return pq_mat


def create_multi_small_fsp_fas(prof_dict, dp, dq, init_fsp_pq):
    for idx, fsp in enumerate(prof_dict):
        if idx != 0:
            pq_mat = signal.convolve2d(pq_mat, profiles_to_mat(prof_dict[fsp], dp, dq, init_fsp_pq[fsp][0]))
        else:
            pq_mat = profiles_to_mat(prof_dict[fsp], dp, dq, init_fsp_pq[fsp][0])
    return pq_mat


def enhance_big_fa(fa):
    # order 0 =  nearest interpolation (1 = bilinear and 2 = cubic)
    # https://stackoverflow.com/questions/13242382/resampling-a-numpy-array-representing-an-image
    new_fa = scipy.ndimage.zoom(fa.astype('float32'), 5., order=0)
    new_fa[new_fa >= 0.5] = 1
    new_fa[new_fa < 0.5] = 0
    return new_fa


def enhance_multi_big_fa(fa, times=5.):
    # order 0 =  nearest interpolation (1 = bilinear and 2 = cubic)
    # https://stackoverflow.com/questions/13242382/resampling-a-numpy-array-representing-an-image
    new_fa = scipy.ndimage.zoom(fa.astype('float64'), times, mode='nearest', order=1)
    return new_fa


def reduce_fa_small(fa):
    # order 0 =  nearest interpolation (1 = bilinear and 2 = cubic)
    # https://stackoverflow.com/questions/13242382/resampling-a-numpy-array-representing-an-image
    new_fa = scipy.ndimage.zoom(fa.astype('float32'), .5, order=1)
    new_fa[new_fa >= 0.5] = 1
    new_fa[new_fa < 0.5] = 0
    return new_fa


def reduce_multi_fa_small(fa, times=0.5):
    # order 0 =  nearest interpolation (1 = bilinear and 2 = cubic)
    # https://stackoverflow.com/questions/13242382/resampling-a-numpy-array-representing-an-image
    new_fa = scipy.ndimage.zoom(fa.astype('float64'), times, mode='nearest', order=1)
    return new_fa


def get_uncertain_fa(pq_mat, large_fa, small_prof_dict, dp, dq, init_fsp_pq, p_axes, q_axes):
    fa_small = create_small_fsp_fas(small_prof_dict, dp / 10, dq / 10, init_fsp_pq)
    fa_large_enhanced = enhance_big_fa(large_fa)
    ones_enhanced = enhance_big_fa(pq_mat)
    fa_small = reduce_fa_small(fa_small)
    # Now reduce the sizes s.t. the convolve will not return NaN
    uncertain_fa = signal.convolve2d(fa_small, fa_large_enhanced, mode='full')
    uncertain_ones_fa = signal.convolve2d(fa_small, ones_enhanced, mode='full')

    scaled_uncertain = pre.MinMaxScaler().fit_transform(uncertain_fa)
    uncertain_fa[uncertain_fa >= 0.1] = 0.5
    uncertain_ones_fa[uncertain_ones_fa >= 0.1] = 1

    large_fa_enh = np.pad(fa_large_enhanced, [(int(len(fa_small) / 2), len(fa_small) - int(len(fa_small) / 2) - 1),
                                              (int(len(fa_small[0]) / 2),
                                               len(fa_small[0]) - int(len(fa_small[0]) / 2) - 1)],
                          mode='constant')

    big_fa_discrete = uncertain_fa + large_fa_enh
    big_fa_discrete[big_fa_discrete > 1] = 1
    big_fa_discrete = big_fa_discrete + uncertain_ones_fa

    big_fa_cont = scaled_uncertain + large_fa_enh
    big_fa_cont[big_fa_cont > 1] = 1
    big_fa_cont = big_fa_cont + uncertain_ones_fa
    p_step = abs((p_axes[-1] - p_axes[0]) / len(fa_large_enhanced[0]))
    q_step = abs((q_axes[-1] - q_axes[0]) / len(fa_large_enhanced))
    new_p_axes = np.arange(p_axes[0] - int(len(fa_small[0]) / 2) * p_step,
                           p_axes[-1] + (len(fa_small[0]) - int(len(fa_small[0]) / 2) - 1) * p_step + 0.5 * p_step,
                           p_step)
    new_q_axes = np.arange(q_axes[0] - int(len(fa_small) / 2) * q_step,
                           q_axes[-1] + (len(fa_small) - int(len(fa_small) / 2) - 1) * q_step + 0.5 * q_step, q_step)
    # todo: check sizes, maybe we loose the last value and we dont need the :len bellow
    return big_fa_discrete, big_fa_cont, new_p_axes[:len(big_fa_discrete[0])], new_q_axes[:len(big_fa_discrete)]


def get_multi_uncertain_fa(pq_mat, large_fa, small_prof_dict, dp, dq, init_fsp_pq, p_axes, q_axes):
    fa_small = create_multi_small_fsp_fas(small_prof_dict, dp / 10, dq / 10, init_fsp_pq)
    fa_large_enhanced = enhance_multi_big_fa(large_fa, 5)
    fa_large_enhanced = np.where((fa_large_enhanced >= 0.5) & (fa_large_enhanced <= 1), 1, fa_large_enhanced)
    fa_large_enhanced[fa_large_enhanced < 0.5] = 0

    ones_enhanced = enhance_multi_big_fa(pq_mat, 5)
    ones_enhanced[ones_enhanced >= 0.5] = 1
    ones_enhanced[ones_enhanced < 0.5] = 0

    fa_small = reduce_multi_fa_small(fa_small, 0.5)
    # fa_large_enhanced *= 1. / fa_small.max()
    # fa_small *= 1./fa_small.max()
    uncertain_fa = signal.convolve2d(fa_small, fa_large_enhanced, mode='full')
    uncertain_ones_fa = signal.convolve2d(fa_small, ones_enhanced, mode='full')

    large_fa_enh = np.pad(fa_large_enhanced, [(int(len(fa_small) / 2), len(fa_small) - int(len(fa_small) / 2) - 1),
                                              (int(len(fa_small[0]) / 2),
                                               len(fa_small[0]) - int(len(fa_small[0]) / 2) - 1)],
                          mode='constant')

    large_fa_ons = fa_large_enhanced.copy()
    large_fa_ons[fa_large_enhanced >= 0.1] = 1
    large_fa_enh_ons = large_fa_enh.copy()
    large_fa_enh_ons[large_fa_enh_ons >= 0.1] = 1
    scaled_uncertain = pre.MinMaxScaler(feature_range=(0, 255)).fit_transform(uncertain_fa)
    safe_area = large_fa_enh.copy()
    safe_area *= 1. / safe_area.max()
    safe_area += large_fa_enh_ons

    uncertain_ones_fa[uncertain_ones_fa != 0] = 1

    p_step = abs((p_axes[-1] - p_axes[0]) / len(fa_large_enhanced[0]))
    q_step = abs((q_axes[-1] - q_axes[0]) / len(fa_large_enhanced))
    new_p_axes = np.arange(p_axes[0] - int(len(fa_small[0]) / 2) * p_step,
                           p_axes[-1] + (len(fa_small[0]) - int(len(fa_small[0]) / 2) - 1) * p_step + 0.5 * p_step,
                           p_step)
    new_q_axes = np.arange(q_axes[0] - int(len(fa_small) / 2) * q_step,
                           q_axes[-1] + (len(fa_small) - int(len(fa_small) / 2) - 1) * q_step + 0.5 * q_step, q_step)
    return scaled_uncertain, safe_area, uncertain_ones_fa, new_p_axes[:len(large_fa_enh[0])], \
           new_q_axes[:len(large_fa_enh)]


def get_init_net_state(net):
    init_v = {}
    init_load = {}
    for i, row in net.res_bus.iterrows():
        init_v[net.bus['name'].iloc[i]] = float(row['vm_pu'])
    for i, row in net.res_line.iterrows():
        init_load[net.line['name'].iloc[i]] = float(row['loading_percent'])
    for i, row in net.res_trafo.iterrows():
        init_load[net.trafo['name'].iloc[i]] = float(row['loading_percent'])
    return init_v, init_load


def tensor_conv_simulations_wrong(net, pq_profiles, resolution, init_pcc_pq):
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    # print(net.res_bus, net.bus)
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)

    pq_mats, mat_dicts, axs_p, axs_q = create_mat_dict_rest(result_dict, resolution)
    conv_denom = tensor_convolve2d_real(pq_mats[list(result_dict.keys())[0]],
                                        mat_dicts[list(result_dict.keys())[0]]['PQ'])
    ones = np.zeros_like(conv_denom)
    ones[conv_denom > 0.5] = 1
    final_ts = ones.copy()
    for net_key in tqdm(list(std_dict[list(std_dict.keys())[0]]['std'].keys()), desc='Network Components'):
        conv_net_key = tensor_convolve2d_real(pq_mats[list(result_dict.keys())[0]],
                                              mat_dicts[list(result_dict.keys())[0]][net_key]).copy()
        for fsp_key in list(result_dict.keys())[1:]:
            if std_dict[fsp_key]['std'][net_key] >= 1e-25:
                conv_net_key += tensor_convolve2d_real(pq_mats[fsp_key], mat_dicts[fsp_key][net_key]).copy()
        if net_key in bus_nm:
            final_ts[abs(conv_net_key + init_v[net_key] * ones) >= 1.05] = 0
            final_ts[abs(conv_net_key + init_v[net_key] * ones) <= 0.95] = 0
        else:
            final_ts[abs(conv_net_key + init_load[net_key] * ones) >= 100] = 0

    final_mat = np.flipud(
        np.fliplr(
            np.einsum('ijk->i', final_ts).reshape((len(std_dict) * resolution + 2, len(std_dict) * resolution + 2)).T))
    final_mat[final_mat > 0] = 1

    non_reduced = np.flipud(np.fliplr(
        np.einsum('ijk->i', conv_denom).reshape((len(std_dict) * resolution + 2, len(std_dict) * resolution + 2)).T))

    non_reduced[non_reduced > 0] = 1

    q_axis, p_axis = get_new_conv_axes2(axs_q, axs_p, len(non_reduced), len(non_reduced.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))
    q_axis = q_axis[::-1]
    p_axis = p_axis[::-1]

    conv_total = pd.DataFrame(final_mat + non_reduced, index=q_axis, columns=p_axis)

    q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
    p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
    conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    return conv_total


def tensor_conv_simulations(net, pq_profiles, dp, dq, init_pcc_pq, small_fsp_prof):
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)

    pq_mat, mat_dicts, axs_p, axs_q = create_mat_dict_rest3(result_dict, dp, dq)

    small_fsps = []
    small_fsp_init = {}
    for key in pq_profiles:
        if len(pq_profiles[key]) == 1:
            small_fsps.append(key)
            small_fsp_init[key] = pq_profiles[key]

    fsp_effective_per_comp = {}
    fsp_ineffective_per_comp = {}
    comps = []
    for comp in list(std_dict[list(std_dict.keys())[0]]['std'].index):
        fsp_effective_per_comp[comp] = []
        fsp_ineffective_per_comp[comp] = []
        comps.append(comp)
    for no, key in enumerate(std_dict):
        if key not in small_fsps:
            for comp in comps:
                if 'Bus' in comp and (
                        abs(std_dict[key]['max'][comp]) >= 0.005 or abs(std_dict[key]['min'][comp]) >= 0.005):
                    fsp_effective_per_comp[comp].append(key)
                    # print(f"For comp {comp}: {mat_dicts[key][comp][max(0,loc_qs[no]-5):loc_qs[no]+5, max(0,loc_ps[no]-5):loc_ps[no]+5]}")
                elif 'Bus' in comp:
                    fsp_ineffective_per_comp[comp].append(key)
                elif abs(std_dict[key]['max'][comp]) >= 1 or abs(std_dict[key]['min'][comp]) > 1:
                    fsp_effective_per_comp[comp].append(key)
                else:
                    fsp_ineffective_per_comp[comp].append(key)
    for comp in init_v:
        if 0.98 <= init_v[comp] <= 1.02:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    for comp in init_load:
        if 80 >= init_load[comp]:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    # print(init_load, init_v)
    # print(f"Ones matrix shape: {pq_mat.shape}")

    # tensor_ones_dict = get_all_tensor_ones(fsp_effective_per_comp, mat_dicts)
    # print(tensor_ones_dict.keys())
    print(fsp_effective_per_comp)
    per_comp_flex = []
    # Find a way to remove components with min and max = 0 (0 std)
    # _ = fsp_effective_per_comp.pop('Bus 0', None)
    for key in fsp_effective_per_comp:
        if fsp_effective_per_comp[key]:
            conv_key = get_conv_key(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v, init_load)
            if fsp_ineffective_per_comp[key]:
                conv_key = get_non_effective_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                # ones_key = get_non_effective_conv(fsp_ineffective_per_comp[key], ones_key, mat_dicts)
                # per_comp_flex.append(np.flipud(np.fliplr(conv_key)))
                per_comp_flex.append(conv_key)
            else:
                per_comp_flex.append(conv_key)
    final_flex = np.prod(per_comp_flex, axis=0)
    final_flex[abs(final_flex) > 0] = 1

    q_axes, p_axes = get_new_conv_axes2(axs_q, axs_p, len(pq_mat), len(pq_mat.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))

    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]

    conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

    q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
    p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
    conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3

    if small_fsp_prof:
        uncert_disc, uncert_cont, uncert_p_axs, uncert_q_axs = get_uncertain_fa(pq_mat, final_flex, small_fsp_prof, dp,
                                                                                dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        discrete_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_disc)), index=uncert_q_axs, columns=uncert_p_axs)
        continuous_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_cont)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        discrete_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
        continuous_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4

    return conv_total, discrete_conv, continuous_conv


def tf_tensor_conv_simulations(net, pq_profiles, dp, dq, init_pcc_pq, small_fsp_prof):
    #  -----------------------------------------Preparation------------------------------------------------------------
    t1_s = time.time()
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    t1_e = time.time()
    #  -----------------------------------------Power Flows------------------------------------------------------------
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)
    # --------------------PF results to network component vs FSP sensitivity dictionary
    pq_mat, mat_dicts, axs_p, axs_q = create_tensor_dict(result_dict, dp, dq)
    t2_e = time.time()
    # --------------------Identify FSPs which are smaller than the resolution (to be used for uncertainty)--------------
    small_fsps = []
    small_fsp_init = {}
    for key in pq_profiles:
        if len(pq_profiles[key]) == 1:
            small_fsps.append(key)
            small_fsp_init[key] = pq_profiles[key]
    t3_e = time.time()
    # ----------------Identify effective and non-efective FSPs per component--------------------------------------------
    fsp_effective_per_comp = {}
    fsp_ineffective_per_comp = {}
    comps = []
    for comp in list(std_dict[list(std_dict.keys())[0]]['std'].index):
        fsp_effective_per_comp[comp] = []
        fsp_ineffective_per_comp[comp] = []
        comps.append(comp)
    for no, key in enumerate(std_dict):
        if key not in small_fsps:
            for comp in comps:
                if 'Bus' in comp and (abs(std_dict[key]['max'][comp]) >= 0.005 or
                                      abs(std_dict[key]['min'][comp]) >= 0.005):
                    fsp_effective_per_comp[comp].append(key)
                elif 'Bus' in comp:
                    fsp_ineffective_per_comp[comp].append(key)
                elif abs(std_dict[key]['max'][comp]) >= 1 or abs(std_dict[key]['min'][comp]) > 1:
                    fsp_effective_per_comp[comp].append(key)
                else:
                    fsp_ineffective_per_comp[comp].append(key)
    t4_e = time.time()
    # ------------------------------Remove components far from constraints----------------------------------------------
    for comp in init_v:
        if 0.98 <= init_v[comp] <= 1.02:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    for comp in init_load:
        if 80 >= init_load[comp]:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    t5_e = time.time()
    # ------------------------ Apply convolutions-----------------------------------------------------------------------
    per_comp_flex = []
    # Find a way to remove components with min and max = 0 (0 std)

    for key in fsp_effective_per_comp:
        if fsp_effective_per_comp[key]:
            # Apply all tensor convolutions and get 2D binary flexibility area
            conv_key = get_fast_conv_key(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v, init_load)
            if fsp_ineffective_per_comp[key]:
                # Convolute 2D tensor-conv flex area with the innefective FSPs
                conv_key = get_non_effective_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                per_comp_flex.append(conv_key)
            else:
                per_comp_flex.append(conv_key)
    final_flex = np.prod(per_comp_flex, axis=0)
    final_flex[abs(final_flex) > 0] = 1
    t6_e = time.time()

    q_axes, p_axes = get_new_conv_axes2(axs_q, axs_p, len(pq_mat), len(pq_mat.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))

    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]

    conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

    q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
    p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
    conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    t7_e = time.time()
    if small_fsp_prof:
        uncert_disc, uncert_cont, uncert_p_axs, uncert_q_axs = get_uncertain_fa(pq_mat, final_flex, small_fsp_prof, dp,
                                                                                dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        discrete_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_disc)), index=uncert_q_axs, columns=uncert_p_axs)
        continuous_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_cont)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        discrete_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
        continuous_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
    t8_e = time.time()
    print(f"Duration distribution: \n    -Preparation = {t1_e - t1_s}s,\n    -Power Flows = {t2_e - t1_e}s,"
          f"\n    -Net. Component vs FSP dictionary = {t3_e - t2_e}s,\n    -Effective FSPs per Component = {t4_e - t3_e}s,"
          f"\n    -Removal Safe Components = {t5_e - t4_e}s,\n    -(Tensor & 2D) Convolutions = {t6_e - t5_e}s,\n"
          f"    -Applying Axes and Init Point = {t7_e - t6_e}s,\n    -Small FSP Uncertainty calculation = {t8_e - t7_e}s")
    return conv_total, discrete_conv, continuous_conv


def numpy_tensor_conv_simulations(net, pq_profiles, dp, dq, init_pcc_pq, small_fsp_prof, ttd=False, multi=False):
    #  -----------------------------------------Preparation------------------------------------------------------------
    t0_s = time.time()
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    t0_e = time.time()
    #  -----------------------------------------Power Flows------------------------------------------------------------
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)
    t1_e = time.time()
    # --------------------PF results to network component vs FSP sensitivity dictionary--------------------------------
    pq_mat, mat_dicts, axs_p, axs_q = create_mat_dict_rest3(result_dict, dp, dq)
    t2_e = time.time()
    # --------------------Identify FSPs which are smaller than the resolution (to be used for uncertainty)--------------
    small_fsps = []
    small_fsp_init = {}
    for key in pq_profiles:
        if len(pq_profiles[key]) == 1:
            small_fsps.append(key)
            small_fsp_init[key] = pq_profiles[key]
    t3_e = time.time()
    # ----------------Identify effective and non-efective FSPs per component--------------------------------------------
    fsp_effective_per_comp = {}
    fsp_ineffective_per_comp = {}
    comps = []
    for comp in list(std_dict[list(std_dict.keys())[0]]['std'].index):
        fsp_effective_per_comp[comp] = []
        fsp_ineffective_per_comp[comp] = []
        comps.append(comp)
    for no, key in enumerate(std_dict):
        if key not in small_fsps:
            for comp in comps:
                if ('Bus' in comp or 'bus' in comp) and (
                        abs(std_dict[key]['max'][comp]) >= 0.01 or abs(std_dict[key]['min'][comp]) >= 0.01):
                    fsp_effective_per_comp[comp].append(key)
                elif 'Bus' in comp or 'bus' in comp:
                    fsp_ineffective_per_comp[comp].append(key)
                elif abs(std_dict[key]['max'][comp]) >= 1 or abs(std_dict[key]['min'][comp]) > 1:
                    fsp_effective_per_comp[comp].append(key)
                else:
                    fsp_ineffective_per_comp[comp].append(key)
    t4_e = time.time()
    # ------------------------------Remove components far from constraints----------------------------------------------
    for comp in init_v:
        if 0.99 <= init_v[comp] <= 1.01:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    for comp in init_load:
        if 80 >= abs(init_load[comp]):
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    t5_e = time.time()
    # ------------------------ Apply convolutions-----------------------------------------------------------------------
    per_comp_flex = []
    # Find a way to remove components with min and max = 0 (0 std)
    print(f"FSP effective per comp {fsp_effective_per_comp}, FSP innefective per comp {fsp_ineffective_per_comp}")
    if not multi:
        for key in fsp_effective_per_comp:
            if fsp_effective_per_comp[key]:
                # Apply all tensor convolutions and get 2D binary flexibility area
                if ttd and len(fsp_effective_per_comp) > 2:
                    conv_key = get_ttd_conv_key(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v, init_load)
                else:
                    conv_key = get_conv_key(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v, init_load)
                if fsp_ineffective_per_comp[key]:
                    # Convolute 2D tensor-conv flex area with the innefective FSPs
                    conv_key = get_non_effective_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                    per_comp_flex.append(conv_key)
                else:
                    per_comp_flex.append(conv_key)
        final_flex = np.prod(per_comp_flex, axis=0)
        final_flex[abs(final_flex) > 0] = 1
    else:
        for key in fsp_effective_per_comp:
            if fsp_effective_per_comp[key]:
                # Apply all tensor convolutions and get 2D binary flexibility area
                conv_key = get_multi_conv_key(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v, init_load)

                if fsp_ineffective_per_comp[key]:
                    # Convolute 2D tensor-conv flex area with the innefective FSPs
                    conv_key = get_non_effective_multi_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                    per_comp_flex.append(conv_key)
                else:
                    per_comp_flex.append(conv_key)
        final_flex = per_comp_flex[0]
        for arr in per_comp_flex[1:]:
            final_flex = np.minimum(final_flex, arr)
        # final_flex = np.prod(per_comp_flex, axis=0)
        if small_fsp_prof:
            final_flex_tmp = final_flex.copy()
        final_flex *= 1. / final_flex.max()
        ff_one = final_flex.copy()
        ff_one[ff_one != 0] = 1
        final_flex += ff_one
    # Apply axes
    t6_e = time.time()
    q_axes, p_axes = get_new_conv_axes2(axs_q, axs_p, len(pq_mat), len(pq_mat.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))

    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]

    if multi:
        conv_total = pd.DataFrame(final_flex, index=q_axis, columns=p_axis)
        inf = pd.DataFrame(pq_mat, index=q_axis, columns=p_axis)
        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        inf.loc[q_axis[q_index], p_axis[p_index]] = 2
    else:
        inf = None
        conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    t7_e = time.time()
    if small_fsp_prof and not multi:
        uncert_disc, uncert_cont, uncert_p_axs, uncert_q_axs = \
            get_uncertain_fa(pq_mat, final_flex, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        discrete_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_disc)), index=uncert_q_axs, columns=uncert_p_axs)
        continuous_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_cont)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index_tmp, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index_tmp, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        discrete_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 4
        continuous_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 4
        ones_conv = None
    elif small_fsp_prof:
        scaled_uncertain, safe_area, uncertain_ones_fa, uncert_p_axs, uncert_q_axs = \
            get_multi_uncertain_fa(pq_mat, final_flex_tmp, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        uncer_conv = pd.DataFrame(np.flipud(np.fliplr(scaled_uncertain)), index=uncert_q_axs, columns=uncert_p_axs)
        safe_conv = pd.DataFrame(np.flipud(np.fliplr(safe_area)), index=uncert_q_axs, columns=uncert_p_axs)
        ones_conv = pd.DataFrame(np.flipud(np.fliplr(uncertain_ones_fa)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index_tmp, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index_tmp, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        safe_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 256
        discrete_conv = uncer_conv
        continuous_conv = safe_conv
    else:
        discrete_conv = None
        continuous_conv = None
        ones_conv = None
    t8_e = time.time()
    print(f"Duration distribution: \n    -Preparation = {t0_e - t0_s}s,\n    -Power Flows = {t1_e - t0_e}s,"
          f"\n    -Net. Component vs FSP dictionary = {t2_e - t1_e}s,\n    -Small FSPs = {t3_e - t2_e}s,"
          f"\n    -Effective FSPs per Component = {t4_e - t3_e}s,"
          f"\n    -Removal Safe Components = {t5_e - t4_e}s,\n    -(Tensor & 2D) Convolutions = {t6_e - t5_e}s,\n"
          f"    -Applying Axes and Init Point = {t7_e - t6_e}s,\n    -Small FSP Uncertainty calculation = {t8_e - t7_e}s")
    return conv_total, discrete_conv, continuous_conv, inf, ones_conv, q_axis[q_index], p_axis[p_index]


def torch_tensor_conv_simulations(net, pq_profiles, dp, dq, init_pcc_pq, small_fsp_prof, ttd=False, multi=True,
                                  comp_fsp_v_sens=0.001, comp_fsp_l_sens=0.1, min_max_v=[0.95, 1.05], max_l=100):
    torch.set_default_dtype(torch.float)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    torch.set_default_device(device)
    #  -----------------------------------------Preparation------------------------------------------------------------
    t0_s = time.time()
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    t0_e = time.time()

    #  -----------------------------------------Power Flows------------------------------------------------------------
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)
    t1_e = time.time()
    # --------------------Identify FSPs which are smaller than the resolution (to be used for uncertainty)--------------
    small_fsps = []
    small_fsp_init = {}
    for key in pq_profiles:
        if len(pq_profiles[key]) == 1:
            small_fsps.append(key)
            small_fsp_init[key] = pq_profiles[key]
    t2_e = time.time()
    # --------------------PF results to network component vs FSP sensitivity dictionary--------------------------------
    # pq_mat = numpy, mat_dicts = torch
    pq_mat, mat_dicts, axs_p, axs_q, unc_fa = create_mat_dict_tensor(result_dict, dp, dq, small_fsps)
    t3_e = time.time()

    # ----------------Identify effective and non-efective FSPs per component--------------------------------------------
    fsp_effective_per_comp = {}
    fsp_ineffective_per_comp = {}
    comps = []
    for comp in list(std_dict[list(std_dict.keys())[0]]['std'].index):
        fsp_effective_per_comp[comp] = []
        fsp_ineffective_per_comp[comp] = []
        comps.append(comp)
    for no, key in enumerate(std_dict):
        if key not in small_fsps:
            for comp in comps:
                if ('Bus' in comp or 'bus' in comp) and (abs(std_dict[key]['max'][comp]) >= comp_fsp_v_sens or
                                                         abs(std_dict[key]['min'][comp]) >= comp_fsp_v_sens):
                    fsp_effective_per_comp[comp].append(key)
                elif 'Bus' in comp or 'bus' in comp:
                    fsp_ineffective_per_comp[comp].append(key)
                elif abs(std_dict[key]['max'][comp]) >= comp_fsp_l_sens or \
                        abs(std_dict[key]['min'][comp]) > comp_fsp_l_sens:
                    print(comp, key)
                    fsp_effective_per_comp[comp].append(key)
                else:
                    fsp_ineffective_per_comp[comp].append(key)
    t4_e = time.time()
    # ------------------------------Remove components far from constraints----------------------------------------------
    for comp in init_v:
        max_dv = 0
        min_dv = 0
        for fpc in fsp_effective_per_comp[comp]:
            max_dv += std_dict[fpc]['max'][comp]
            min_dv += std_dict[fpc]['min'][comp]
            # max_dv += abs(std_dict[fpc]['std'][comp])
            # min_dv += -abs(std_dict[fpc]['std'][comp])
        if min_max_v[0] - min_dv <= init_v[comp] <= min_max_v[1] - max_dv:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    for comp in init_load:
        max_dl = 0
        min_dl = 0
        for fpc in fsp_effective_per_comp[comp]:
            max_dl += std_dict[fpc]['max'][comp]
            min_dl += std_dict[fpc]['min'][comp]
            # max_dl += abs(std_dict[fpc]['std'][comp])
            # min_dl += -abs(std_dict[fpc]['std'][comp])
        if max_l >= abs(init_load[comp] + max_dl) and max_l >= abs(init_load[comp] + min_dl):
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    t5_e = time.time()
    # ------------------------ Apply convolutions-----------------------------------------------------------------------
    per_comp_flex = []

    # Find a way to remove components with min and max = 0 (0 std)
    print(f"FSP effective per comp {fsp_effective_per_comp}")
    if not multi:
        assert False, "TODO"
    else:
        for key in tqdm(fsp_effective_per_comp, desc="Network Components FAs"):
            if fsp_effective_per_comp[key]:
                # Apply all tensor convolutions and get 2D binary flexibility area
                conv_key = get_multi_conv_torch(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v, init_load,
                                                max_v=min_max_v[1], min_v=min_max_v[0])

                if fsp_ineffective_per_comp[key]:
                    # Convolute 2D tensor-conv flex area with the innefective FSPs
                    conv_key = get_non_effective_multi_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                    per_comp_flex.append(conv_key)
                else:
                    per_comp_flex.append(conv_key)
        if len(per_comp_flex) != 0:
            final_flex = per_comp_flex[0]
            for arr in per_comp_flex[1:]:
                final_flex = np.minimum(final_flex, arr)
        else:
            final_flex = unc_fa
        # final_flex = np.prod(per_comp_flex, axis=0)
        final_flex = final_flex.astype(float)
        if small_fsp_prof:
            final_flex_tmp = final_flex.copy()
        final_flex *= 1. / final_flex.max()
        ff_one = final_flex.copy()
        ff_one[ff_one != 0] = 1
        final_flex += ff_one
    # Apply axes
    t6_e = time.time()

    q_axes, p_axes = get_new_conv_axes2(axs_q, axs_p, len(pq_mat), len(pq_mat.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))
    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]
    extra = []
    if multi:
        conv_total = pd.DataFrame(final_flex, index=q_axis[:len(final_flex)], columns=p_axis[:len(final_flex[0])])
        inf = pd.DataFrame(pq_mat, index=q_axis, columns=p_axis)
        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        inf.loc[q_axis[q_index], p_axis[p_index]] = 2
        # plt.figure()
        # ax = sns.heatmap(inf)
        # plt.show()
    else:
        inf = None
        conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    t7_e = time.time()
    if small_fsp_prof and not multi:
        uncert_disc, uncert_cont, uncert_p_axs, uncert_q_axs = \
            get_uncertain_fa(pq_mat, final_flex, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        discrete_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_disc)), index=uncert_q_axs, columns=uncert_p_axs)
        continuous_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_cont)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index_tmp, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index_tmp, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        discrete_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 4
        continuous_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 4
        ones_conv = None
    elif small_fsp_prof:
        scaled_uncertain, safe_area, uncertain_ones_fa, uncert_p_axs, uncert_q_axs = \
            get_multi_uncertain_fa(pq_mat, final_flex_tmp, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        uncer_conv = pd.DataFrame(np.flipud(np.fliplr(scaled_uncertain)), index=uncert_q_axs, columns=uncert_p_axs)
        safe_conv = pd.DataFrame(np.flipud(np.fliplr(safe_area)), index=uncert_q_axs, columns=uncert_p_axs)
        ones_conv = pd.DataFrame(np.flipud(np.fliplr(uncertain_ones_fa)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index_tmp, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index_tmp, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        # safe_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 256
        discrete_conv = uncer_conv
        continuous_conv = safe_conv
        extra = [len(uncert_p_axs) - p_index_tmp, len(uncert_q_axs) - q_index_tmp]
    else:
        discrete_conv = None
        continuous_conv = None
        ones_conv = None
    t8_e = time.time()
    dur_str = f"Duration distribution: \n    -Preparation={t0_e - t0_s}s,\n    -Power Flows={t1_e - t0_e}s," + \
              f"\n    -Net. Component vs FSP dictionary={t3_e - t2_e}s,\n    -Small FSPs={t2_e - t1_e}s," + \
              f"\n    -Effective FSPs per Component={t4_e - t3_e}s," + \
              f"\n    -Removal Safe Components={t5_e - t4_e}s,\n    -(Tensor & 2D) Convolutions={t6_e - t5_e}s,\n" + \
              f"    -Applying Axes and Init Point={t7_e - t6_e}s,\n    -Small FSP Uncertainty calculation={t8_e - t7_e}s"
    return conv_total, discrete_conv, continuous_conv, inf, ones_conv, q_index, p_index, dur_str, extra


def torch_tensor_conv_large_simulations(net, pq_profiles, dp, dq, init_pcc_pq, small_fsp_prof, dist_dicts, ttd=False,
                                        multi=False, comp_fsp_v_sens=0.001, comp_fsp_l_sens=0.1,
                                        min_max_v=[0.95, 1.05], max_l=100, no_max=5):
    torch.set_default_dtype(torch.float)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    torch.set_default_device(device)
    #  -----------------------------------------Preparation------------------------------------------------------------
    t0_s = time.time()
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    t0_e = time.time()
    #  -----------------------------------------Power Flows------------------------------------------------------------
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)
    t1_e = time.time()
    # --------------------PF results to network component vs FSP sensitivity dictionary--------------------------------
    # pq_mat = numpy, mat_dicts = torch
    pq_mat, mat_dicts, axs_p, axs_q, unc_fa, init_ids = create_mat_dict_tensorv2(result_dict, dp, dq)
    t2_e = time.time()
    # --------------------Identify FSPs which are smaller than the resolution (to be used for uncertainty)--------------
    small_fsps = []
    small_fsp_init = {}
    for key in pq_profiles:
        if len(pq_profiles[key]) == 1:
            small_fsps.append(key)
            small_fsp_init[key] = pq_profiles[key]
    del pq_profiles
    t3_e = time.time()
    # ----------------Identify effective and non-efective FSPs per component--------------------------------------------
    fsp_effective_per_comp = {}
    fsp_ineffective_per_comp = {}
    comps = []
    for comp in list(std_dict[list(std_dict.keys())[0]]['std'].index):
        fsp_effective_per_comp[comp] = []
        fsp_ineffective_per_comp[comp] = []
        comps.append(comp)
    for no, key in enumerate(std_dict):
        if key not in small_fsps:
            for comp in comps:
                if ('Bus' in comp or 'bus' in comp) and (abs(std_dict[key]['max'][comp]) >= comp_fsp_v_sens or
                                                         abs(std_dict[key]['min'][comp]) >= comp_fsp_v_sens):
                    fsp_effective_per_comp[comp].append(key)
                elif 'Bus' in comp or 'bus' in comp:
                    fsp_ineffective_per_comp[comp].append(key)
                elif abs(std_dict[key]['max'][comp]) >= comp_fsp_l_sens or \
                        abs(std_dict[key]['min'][comp]) > comp_fsp_l_sens:
                    fsp_effective_per_comp[comp].append(key)
                else:
                    fsp_ineffective_per_comp[comp].append(key)
    t4_e = time.time()
    # ------------------------------Remove components far from constraints----------------------------------------------
    for comp in init_v:
        max_dv = 0
        min_dv = 0
        for fpc in fsp_effective_per_comp[comp]:
            max_dv += std_dict[fpc]['max'][comp]
            min_dv += std_dict[fpc]['min'][comp]
        if min_max_v[0] - min_dv <= init_v[comp] <= min_max_v[1] - max_dv:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    for comp in init_load:
        max_dl = 0
        min_dl = 0
        for fpc in fsp_effective_per_comp[comp]:
            max_dl += std_dict[fpc]['max'][comp]
            min_dl += std_dict[fpc]['min'][comp]
        if max_l >= abs(init_load[comp] + max_dl) and max_l >= abs(init_load[comp] + min_dl):
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    t5_e = time.time()
    # ------------------------ Apply convolutions-----------------------------------------------------------------------
    per_comp_flex = []
    seen = 0
    # Find a way to remove components with min and max = 0 (0 std)
    # print(f"FSP effective per comp {fsp_effective_per_comp}, FSP innefective per comp {fsp_ineffective_per_comp}")
    if not multi:
        assert False, "TODO"
    else:
        for key in tqdm(fsp_effective_per_comp, desc="Network Components FAs"):
            if fsp_effective_per_comp[key]:
                # Apply all tensor convolutions and get 2D binary flexibility area
                if len(fsp_effective_per_comp[key]) >= no_max:
                    seen = 1
                    conv_key = get_multi_conv_torch_split(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v,
                                                          init_load, dist_dicts, init_ids, max_v=min_max_v[1],
                                                          min_v=min_max_v[0], no_max=no_max)
                else:
                    conv_key = get_multi_conv_torch(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v,
                                                    init_load,
                                                    max_v=min_max_v[1], min_v=min_max_v[0])
                if fsp_ineffective_per_comp[key]:
                    # Convolute 2D tensor-conv flex area with the innefective FSPs
                    conv_key = get_non_effective_multi_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                    per_comp_flex.append(conv_key)
                else:
                    per_comp_flex.append(conv_key)
        if len(per_comp_flex) != 0:
            final_flex = per_comp_flex[0]
            for arr in per_comp_flex[1:]:
                final_flex = np.minimum(final_flex, arr)
        else:
            final_flex = unc_fa
        # final_flex = np.prod(per_comp_flex, axis=0)
        final_flex = final_flex.astype(float)
        if small_fsp_prof:
            final_flex_tmp = final_flex.copy()
        final_flex *= 1. / final_flex.max()
        ff_one = final_flex.copy()
        ff_one[ff_one != 0] = 1
        final_flex += ff_one
    # Apply axes
    t6_e = time.time()
    q_axes, p_axes = get_new_conv_axes2(axs_q, axs_p, len(pq_mat), len(pq_mat.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))

    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]
    if multi:
        conv_total = pd.DataFrame(final_flex, index=q_axis[:len(final_flex)], columns=p_axis[:len(final_flex[0])])
        inf = pd.DataFrame(pq_mat, index=q_axis, columns=p_axis)
        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        inf.loc[q_axis[q_index], p_axis[p_index]] = 2
        # plt.figure()
        # ax = sns.heatmap(inf)
        # plt.show()
    else:
        inf = None
        conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    t7_e = time.time()
    if small_fsp_prof and not multi:
        uncert_disc, uncert_cont, uncert_p_axs, uncert_q_axs = \
            get_uncertain_fa(pq_mat, final_flex, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        discrete_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_disc)), index=uncert_q_axs, columns=uncert_p_axs)
        continuous_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_cont)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index_tmp, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index_tmp, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        discrete_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 4
        continuous_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 4
        ones_conv = None
    elif small_fsp_prof:
        scaled_uncertain, safe_area, uncertain_ones_fa, uncert_p_axs, uncert_q_axs = \
            get_multi_uncertain_fa(pq_mat, final_flex_tmp, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        uncer_conv = pd.DataFrame(np.flipud(np.fliplr(scaled_uncertain)), index=uncert_q_axs, columns=uncert_p_axs)
        safe_conv = pd.DataFrame(np.flipud(np.fliplr(safe_area)), index=uncert_q_axs, columns=uncert_p_axs)
        ones_conv = pd.DataFrame(np.flipud(np.fliplr(uncertain_ones_fa)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index_tmp, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index_tmp, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        safe_conv.loc[uncert_q_axs[-q_index_tmp], uncert_p_axs[-p_index_tmp]] = 256
        discrete_conv = uncer_conv
        continuous_conv = safe_conv
    else:
        discrete_conv = None
        continuous_conv = None
        ones_conv = None
    t8_e = time.time()
    dur_str = f"Duration distribution: \n    -Preparation={t0_e - t0_s}s,\n    -Power Flows={t1_e - t0_e}s," + \
              f"\n    -Net. Component vs FSP dictionary={t2_e - t1_e}s,\n    -Small FSPs={t3_e - t2_e}s," + \
              f"\n    -Effective FSPs per Component={t4_e - t3_e}s," + \
              f"\n    -Removal Safe Components={t5_e - t4_e}s,\n    -(Tensor & 2D) Convolutions={t6_e - t5_e}s,\n" + \
              f"    -Applying Axes and Init Point={t7_e - t6_e}s,\n    -Small FSP Uncertainty calculation={t8_e - t7_e}s,"
    return conv_total, discrete_conv, continuous_conv, inf, ones_conv, q_index, p_index, dur_str


def split_lin_from_non_lin(comp_dict, non_lin_fsp):
    non_lin_comp_dict = {}
    for key in comp_dict:
        idx = 0
        to_append = []
        for fsp in comp_dict[key]:
            if fsp in non_lin_fsp:
                to_append.append(comp_dict[key].pop(idx))
            else:
                idx += 1
        non_lin_comp_dict[key] = to_append
    return comp_dict, non_lin_comp_dict


def numpy_tensor_conv_simulations_with_delta(net, pq_profiles, dp, dq, init_pcc_pq, small_fsp_prof, ttd=False,
                                             multi=False, non_lin_fsp=[], min_v=0.95, max_v=1.05):
    #  -----------------------------------------Preparation------------------------------------------------------------
    print(min_v, max_v)
    t0_s = time.time()
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    t0_e = time.time()
    #  -----------------------------------------Power Flows------------------------------------------------------------
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)
    t1_e = time.time()
    # --------------------PF results to network component vs FSP sensitivity dictionary--------------------------------
    pq_mat, mat_dicts, axs_p, axs_q, axs_p_with_delta, axs_q_with_delta, unc_fa = \
        create_mat_dict_incl_delta(result_dict, dp, dq, non_lin_fsp, init_pcc_pq)
    t2_e = time.time()
    # --------------------Identify FSPs which are smaller than the resolution (to be used for uncertainty)--------------
    small_fsps = []
    small_fsp_init = {}
    for key in pq_profiles:
        if len(pq_profiles[key]) == 1:
            small_fsps.append(key)
            small_fsp_init[key] = pq_profiles[key]
    t3_e = time.time()
    # ----------------Identify effective and non-efective FSPs per component--------------------------------------------
    fsp_effective_per_comp = {}
    fsp_ineffective_per_comp = {}
    comps = []
    for comp in list(std_dict[list(std_dict.keys())[0]]['std'].index):
        fsp_effective_per_comp[comp] = []
        fsp_ineffective_per_comp[comp] = []
        comps.append(comp)
    for no, key in enumerate(std_dict):
        if key not in small_fsps:
            for comp in comps:
                if 'Bus' in comp and (
                        abs(std_dict[key]['max'][comp]) >= 0.002 or
                        abs(std_dict[key]['min'][comp]) >= 0.002):
                    fsp_effective_per_comp[comp].append(key)
                elif 'Bus' in comp:
                    fsp_ineffective_per_comp[comp].append(key)
                elif abs(std_dict[key]['max'][comp]) >= 1 or abs(std_dict[key]['min'][comp]) > 1:
                    fsp_effective_per_comp[comp].append(key)
                else:
                    fsp_ineffective_per_comp[comp].append(key)
    t4_e = time.time()
    # ------------------------------Remove components far from constraints----------------------------------------------
    for comp in init_v:
        if 0.98 <= init_v[comp] <= 1.02:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    for comp in init_load:
        if 60 >= init_load[comp]:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    t5_e = time.time()
    # ---------------------------Distinguish Non-Linear Effective FSPs from Comp-----------------------------------------------------------------
    fsp_effective_per_comp, non_lin_eff_fsp_per_comp = split_lin_from_non_lin(fsp_effective_per_comp, non_lin_fsp)
    fsp_ineffective_per_comp, non_lin_ineff_fsp_per_comp = split_lin_from_non_lin(fsp_ineffective_per_comp, non_lin_fsp)
    print(non_lin_fsp, fsp_effective_per_comp, fsp_ineffective_per_comp)
    # ------------------------ Apply convolutions-----------------------------------------------------------------------
    per_comp_flex = []
    # Find a way to remove components with min and max = 0 (0 std)
    any_effective = False
    if not multi:
        for key in tqdm(fsp_effective_per_comp, desc="Network Components FAs"):
            if fsp_effective_per_comp[key]:
                any_effective = True
                # Apply all tensor convolutions and get 2D binary flexibility area
                if ttd and len(fsp_effective_per_comp) > 2:
                    # todo: currently not working with delta
                    conv_key = get_ttd_conv_key(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v, init_load)
                else:
                    # todo: currently not working with delta
                    conv_key = get_conv_key(fsp_effective_per_comp[key], mat_dicts, key, bus_nm,
                                            init_v, init_load)
                if fsp_ineffective_per_comp[key]:
                    # Convolute 2D tensor-conv flex area with the innefective FSPs
                    conv_key = get_non_effective_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                    per_comp_flex.append(conv_key)
                else:
                    per_comp_flex.append(conv_key)
        if not any_effective:
            final_flex = get_result_for_0_effective(fsp_ineffective_per_comp[key], mat_dicts)
        else:
            final_flex = np.prod(per_comp_flex, axis=0)
        final_flex[abs(final_flex) > 0] = 1
    else:
        for key in tqdm(fsp_effective_per_comp, desc="Network Components FAs"):
            if fsp_effective_per_comp[key]:
                any_effective = True
                # Apply all tensor convolutions and get 2D binary flexibility area
                conv_key = get_multi_conv_key_with_delta(fsp_effective_per_comp[key], mat_dicts, key, bus_nm,
                                                         init_v, init_load, non_lin_eff_fsp_per_comp[key], [dp, dq],
                                                         min_v, max_v)
                if fsp_ineffective_per_comp[key]:
                    # Convolute 2D tensor-conv flex area with the innefective FSPs
                    conv_key = get_non_effective_multi_conv_with_delta(fsp_ineffective_per_comp[key], conv_key,
                                                                       mat_dicts, non_lin_ineff_fsp_per_comp[key],
                                                                       [dp, dq])
                    per_comp_flex.append(conv_key)
                else:
                    per_comp_flex.append(conv_key)
        if not any_effective:
            final_flex = get_multi_result_for_0_effective(fsp_ineffective_per_comp[key], mat_dicts)
            final_flex = get_result_for_0_effective_with_delta(final_flex, non_lin_eff_fsp_per_comp,
                                                               non_lin_ineff_fsp_per_comp, [dp, dq], bus_nm,
                                                               init_v, init_load, mat_dicts)
        else:
            final_flex = per_comp_flex[0]
            for arr in per_comp_flex[1:]:
                final_flex = np.minimum(final_flex, arr)
            # final_flex = np.prod(per_comp_flex, axis=0)
        # Normalize
        if final_flex.max() > 0:
            final_flex *= 1. / final_flex.max()
            ff_one = final_flex.copy()
            ff_one[ff_one != 0] = 1
            final_flex += ff_one
    # Apply axes
    t6_e = time.time()
    q_axes, p_axes = get_new_conv_axes2(axs_q_with_delta, axs_p_with_delta, len(pq_mat), len(pq_mat.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))

    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]

    if multi:
        if len(q_axis) < len(final_flex):
            start_end_q = [len(final_flex) - len(q_axis), len(final_flex)]
        elif len(q_axis) > len(final_flex):
            q_axis = q_axis[:len(final_flex)]
            start_end_q = [0, len(final_flex)]
        else:
            start_end_q = [0, len(final_flex)]
        if len(p_axis) < len(final_flex[0]):
            start_end_p = [len(final_flex[0]) - len(p_axis), len(final_flex[0])]
        elif len(p_axis) > len(final_flex[0]):
            p_axis = p_axis[:len(final_flex[0])]
            start_end_p = [0, len(final_flex[0])]
        else:
            start_end_p = [0, len(final_flex[0])]
        conv_total = pd.DataFrame(final_flex[start_end_q[0]:start_end_q[1], start_end_p[0]:start_end_p[1]],
                                  index=q_axis, columns=p_axis)
        # conv_total = pd.DataFrame(final_flex[:len(q_axis), :len(p_axis)], index=q_axis, columns=p_axis)
        inf = pd.DataFrame(pq_mat[start_end_q[0]:start_end_q[1], start_end_p[0]:start_end_p[1]], index=q_axis,
                           columns=p_axis)
        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        inf.loc[q_axis[q_index], p_axis[p_index]] = 2
    else:
        inf = None
        conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    t7_e = time.time()
    if small_fsp_prof and not multi:
        uncert_disc, uncert_cont, uncert_p_axs, uncert_q_axs = \
            get_uncertain_fa(pq_mat, final_flex, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        discrete_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_disc)), index=uncert_q_axs, columns=uncert_p_axs)
        continuous_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_cont)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        discrete_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
        continuous_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
    elif small_fsp_prof:
        assert Warning, "Warning: Simultaneous Uncertainty and Multiplicity currently not supported"
        discrete_conv = None
        continuous_conv = None
    else:
        discrete_conv = None
        continuous_conv = None
    t8_e = time.time()
    print(f"Duration distribution: \n    -Preparation = {t0_e - t0_s}s,\n    -Power Flows = {t1_e - t0_e}s,"
          f"\n    -Net. Component vs FSP dictionary = {t2_e - t1_e}s,\n    -Small FSPs = {t3_e - t2_e}s,"
          f"\n    -Effective FSPs per Component = {t4_e - t3_e}s,"
          f"\n    -Removal Safe Components = {t5_e - t4_e}s,\n    -(Tensor & 2D) Convolutions = {t6_e - t5_e}s,\n"
          f"    -Applying Axes and Init Point = {t7_e - t6_e}s,\n    -Small FSP Uncertainty calculation = {t8_e - t7_e}s")
    return conv_total, discrete_conv, continuous_conv, inf, q_index, p_index  # q_axis[q_index], p_axis[p_index]


def numpy_tensor_conv_simulations_saving(net, pq_profiles, dp, dq, init_pcc_pq, small_fsp_prof, ttd=False, multi=False,
                                         comp_fsp_v_sens=0.001, comp_fsp_l_sens=0.1, min_max_v=[0.95, 1.05], max_l=100):
    #  -----------------------------------------Preparation------------------------------------------------------------
    t0_s = time.time()
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    t0_e = time.time()
    #  -----------------------------------------Power Flows------------------------------------------------------------
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)
    t1_e = time.time()
    # --------------------PF results to network component vs FSP sensitivity dictionary--------------------------------
    pq_mat, mat_dicts, axs_p, axs_q, fsps_ordered = create_mat_dict_order(result_dict, dp, dq)
    t2_e = time.time()
    # --------------------Identify FSPs which are smaller than the resolution (to be used for uncertainty)--------------
    small_fsps = []
    small_fsp_init = {}
    for key in pq_profiles:
        if len(pq_profiles[key]) == 1:
            small_fsps.append(key)
            small_fsp_init[key] = pq_profiles[key]
    t3_e = time.time()
    # ----------------Identify effective and non-efective FSPs per component--------------------------------------------
    fsp_effective_per_comp = {}
    fsp_ineffective_per_comp = {}
    comps = []
    for comp in list(std_dict[list(std_dict.keys())[0]]['std'].index):
        fsp_effective_per_comp[comp] = []
        fsp_ineffective_per_comp[comp] = []
        comps.append(comp)
    for no, key in enumerate(std_dict):
        if key not in small_fsps:
            for comp in comps:
                if ('Bus' in comp or 'bus' in comp) and (abs(std_dict[key]['max'][comp]) >= comp_fsp_v_sens or
                                                         abs(std_dict[key]['min'][comp]) >= comp_fsp_v_sens):
                    fsp_effective_per_comp[comp].append(key)
                elif 'Bus' in comp or 'bus' in comp:
                    fsp_ineffective_per_comp[comp].append(key)
                elif abs(std_dict[key]['max'][comp]) >= comp_fsp_l_sens or \
                        abs(std_dict[key]['min'][comp]) > comp_fsp_l_sens:
                    fsp_effective_per_comp[comp].append(key)
                else:
                    fsp_ineffective_per_comp[comp].append(key)
    t4_e = time.time()
    # ------------------------------Remove components far from constraints----------------------------------------------
    comps_shifts = {}
    for comp in init_v:
        max_dv = 0
        min_dv = 0
        for fpc in fsp_effective_per_comp[comp]:
            max_dv += std_dict[fpc]['max'][comp]
            min_dv += std_dict[fpc]['min'][comp]
        if min_max_v[0] - min_dv <= init_v[comp] <= min_max_v[1] - max_dv:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
        else:
            comps_shifts[comp] = [min_dv, max_dv]
    for comp in init_load:
        max_dl = 0
        min_dl = 0
        for fpc in fsp_effective_per_comp[comp]:
            max_dl += std_dict[fpc]['max'][comp]
            min_dl += std_dict[fpc]['min'][comp]
        if max_l >= abs(init_load[comp] + max_dl) and max_l >= abs(init_load[comp] + min_dl):
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
        else:
            comps_shifts[comp] = [min_dl, max_dl]
    t5_e = time.time()
    # ------------------------Save FSP effective dict-------------------------------------------------------------------
    with open("drive/MyDrive/TCPlus/csv_results/adapt/FSP_effective_per_Comp.json", "w") as fp:
        json.dump({'Effective': fsp_effective_per_comp, 'Non-Effective': fsp_ineffective_per_comp,
                   'FSPs': fsps_ordered, 'axs_pq': [[ap.tolist() for ap in axs_p], [aq.tolist() for aq in axs_q]],
                   'Shifts': comps_shifts}, fp)
    np.save("drive/MyDrive/TCPlus/csv_results/adapt/mat_dicts.npy", mat_dicts)
    np.save("drive/MyDrive/TCPlus/csv_results/adapt/pq_mat.npy", pq_mat)
    # ------------------------ Apply convolutions-----------------------------------------------------------------------
    per_comp_flex = []
    # Find a way to remove components with min and max = 0 (0 std)
    for key in tqdm(fsp_effective_per_comp, desc="Network Components FAs"):
        if fsp_effective_per_comp[key]:
            # Apply all tensor convolutions and get 2D binary flexibility area
            conv_key = get_multi_conv_key_saving(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v,
                                                 init_load, max_v=min_max_v[1], min_v=min_max_v[0])
            if fsp_ineffective_per_comp[key]:
                # Convolute 2D tensor-conv flex area with the innefective FSPs
                conv_key = get_non_effective_multi_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                per_comp_flex.append(conv_key)
            else:
                per_comp_flex.append(conv_key)
    final_flex = per_comp_flex[0]
    for arr in per_comp_flex[1:]:
        final_flex = np.minimum(final_flex, arr)
    # final_flex = np.prod(per_comp_flex, axis=0)
    final_flex *= 1. / final_flex.max()
    ff_one = final_flex.copy()
    ff_one[ff_one != 0] = 1
    final_flex += ff_one
    # Apply axes
    t6_e = time.time()
    q_axes, p_axes = get_new_conv_axes2(axs_q, axs_p, len(pq_mat), len(pq_mat.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))
    p_shifts = [p_vl - float(init_pcc_pq[0]) for p_vl in p_axes]
    q_shifts = [q_vl - float(init_pcc_pq[1]) for q_vl in q_axes]

    # np.save("drive/MyDrive/TCPlus/csv_results/adapt/pq_axes.npy", np.array([p_shifts, q_shifts]))
    np.save("drive/MyDrive/TCPlus/csv_results/adapt/p_axis.npy", np.array(p_shifts))
    np.save("drive/MyDrive/TCPlus/csv_results/adapt/q_axis.npy", np.array(q_shifts))
    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]

    if multi:
        conv_total = pd.DataFrame(final_flex, index=q_axis, columns=p_axis)
        inf = pd.DataFrame(pq_mat, index=q_axis, columns=p_axis)
        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        inf.loc[q_axis[q_index], p_axis[p_index]] = 2
    else:
        inf = None
        conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    t7_e = time.time()
    if small_fsp_prof and not multi:
        uncert_disc, uncert_cont, uncert_p_axs, uncert_q_axs = \
            get_uncertain_fa(pq_mat, final_flex, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        discrete_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_disc)), index=uncert_q_axs, columns=uncert_p_axs)
        continuous_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_cont)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        discrete_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
        continuous_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
    elif small_fsp_prof:
        assert Warning, "Warning: Simultaneous Uncertainty and Multiplicity currently not supported"
        discrete_conv = None
        continuous_conv = None
    else:
        discrete_conv = None
        continuous_conv = None
    t8_e = time.time()
    print(f"Duration distribution: \n    -Preparation = {t0_e - t0_s}s,\n    -Power Flows = {t1_e - t0_e}s,"
          f"\n    -Net. Component vs FSP dictionary = {t2_e - t1_e}s,\n    -Small FSPs = {t3_e - t2_e}s,"
          f"\n    -Effective FSPs per Component = {t4_e - t3_e}s,"
          f"\n    -Removal Safe Components = {t5_e - t4_e}s,\n    -(Tensor & 2D) Convolutions = {t6_e - t5_e}s,\n"
          f"    -Applying Axes and Init Point = {t7_e - t6_e}s,\n    -Small FSP Uncertainty calculation = {t8_e - t7_e}s")
    return conv_total, discrete_conv, continuous_conv, inf, q_axis[q_index], p_axis[p_index]


def adaptable_new_fsp(net, pq_profiles, dp, dq, init_pcc_pq, small_fsp_prof, multi=False):
    #  -----------------------------------------Preparation------------------------------------------------------------
    t0_s = time.time()
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    t0_e = time.time()

    # ------------------------Load FSP effective dict------------------------------------------------------------------
    with open("csv_results/adapt/FSP_effective_per_Comp.json", "r") as fp:
        old_vals = json.load(fp)
    old_fsp_effective_per_comp = old_vals['Effective']
    old_fsp_ineffective_per_comp = old_vals['Non-Effective']
    seen_FSPs = old_vals['FSPs']
    new_FSPs = list(set(list(pq_profiles.keys())) - set(seen_FSPs))
    lost_FSPs = list(set(seen_FSPs) - set(list(pq_profiles.keys())))
    old_axs_pq = old_vals['axs_pq']
    old_mat_dicts = np.load("csv_results/adapt/mat_dicts.npy", allow_pickle=True)
    # First remove lost FSPs from axs todo: do the same for tensors
    for i, fsp in enumerate(lost_FSPs):
        del old_axs_pq[0][i]
        del old_axs_pq[1][i]
    pq_profiles = {key: pq_profiles[key] for key in new_FSPs}
    #  -----------------------------------------Power Flows------------------------------------------------------------
    result_dict, std_dict, duration = run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm,
                                                                init_v, init_load)
    t1_e = time.time()
    # --------------------PF results to network component vs FSP sensitivity dictionary--------------------------------
    if pq_profiles:
        pq_mat, mat_dicts, axs_p, axs_q = create_mat_dict_rest3(result_dict, dp, dq)
        axs_p += old_axs_pq[0]
        axs_q += old_axs_pq[1]
    else:
        pq_mat = []
        mat_dicts = {}
        axs_p = old_axs_pq[0]
        axs_q = old_axs_pq[1]
    # Add axs of new FSPs # todo: recompute pq_mat after retrieving tensors

    t2_e = time.time()
    # --------------------Identify FSPs which are smaller than the resolution (to be used for uncertainty)--------------
    small_fsps = []
    small_fsp_init = {}
    for key in pq_profiles:
        if len(pq_profiles[key]) == 1:
            small_fsps.append(key)
            small_fsp_init[key] = pq_profiles[key]
    t3_e = time.time()
    # ----------------Identify effective and non-efective FSPs per component--------------------------------------------
    fsp_effective_per_comp = {}
    fsp_ineffective_per_comp = {}
    comps = []
    if std_dict:
        for comp in list(std_dict[list(std_dict.keys())[0]]['std'].index):
            fsp_effective_per_comp[comp] = []
            fsp_ineffective_per_comp[comp] = []
            comps.append(comp)
        for no, key in enumerate(std_dict):
            if key not in small_fsps:
                for comp in comps:
                    if 'Bus' in comp and (
                            abs(std_dict[key]['max'][comp]) >= 0.005 or abs(std_dict[key]['min'][comp]) >= 0.005):
                        fsp_effective_per_comp[comp].append(key)
                    elif 'Bus' in comp:
                        fsp_ineffective_per_comp[comp].append(key)
                    elif abs(std_dict[key]['max'][comp]) >= 1 or abs(std_dict[key]['min'][comp]) > 1:
                        fsp_effective_per_comp[comp].append(key)
                    else:
                        fsp_ineffective_per_comp[comp].append(key)
    t4_e = time.time()
    # ------------------------------Remove components far from constraints----------------------------------------------
    for comp in init_v:
        if 0.98 <= init_v[comp] <= 1.02:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    for comp in init_load:
        if 80 >= init_load[comp]:
            _ = fsp_effective_per_comp.pop(comp, None)
            _ = fsp_ineffective_per_comp.pop(comp, None)
    t5_e = time.time()
    # ------------------------ Apply convolutions-----------------------------------------------------------------------
    per_comp_flex = []
    # Find a way to remove components with min and max = 0 (0 std)
    if not multi:
        for key in tqdm(fsp_effective_per_comp, desc="Network Components FAs"):
            if fsp_effective_per_comp[key]:
                # Apply all tensor convolutions and get 2D binary flexibility area
                # -----------------------Load Tensors ------------------------------------------------------------------
                conv_key = get_conv_key_adapting(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v, init_load)
                if fsp_ineffective_per_comp[key] and not old_fsp_ineffective_per_comp[key]:
                    # Convolute 2D tensor-conv flex area with the innefective FSPs
                    conv_key = get_non_effective_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                    per_comp_flex.append(conv_key)
                elif not fsp_ineffective_per_comp[key] and old_fsp_ineffective_per_comp[key]:
                    conv_key = get_non_effective_conv(old_fsp_ineffective_per_comp[key], conv_key, old_mat_dicts)
                    per_comp_flex.append(conv_key)
                elif fsp_ineffective_per_comp[key] and old_fsp_ineffective_per_comp[key]:
                    conv_key = get_non_effective_conv(fsp_ineffective_per_comp[key], conv_key, old_mat_dicts)
                    conv_key = get_non_effective_conv(old_fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                    per_comp_flex.append(conv_key)
                else:
                    per_comp_flex.append(conv_key)
            else:
                try:
                    pre_tensor = torch.load(f'csv_results/adapt/ttd{comp}.pt').torch().cpu().numpy()
                except:
                    pre_tensor = None
                if pre_tensor is not None:
                    conv_key = adapt_only_old_effective(pre_tensor, comp, bus_nm, init_v, init_load)
                    if fsp_ineffective_per_comp[key] and not old_fsp_ineffective_per_comp[key]:
                        # Convolute 2D tensor-conv flex area with the innefective FSPs
                        conv_key = get_non_effective_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                        per_comp_flex.append(conv_key)
                    elif not fsp_ineffective_per_comp[key] and old_fsp_ineffective_per_comp[key]:
                        conv_key = get_non_effective_conv(old_fsp_ineffective_per_comp[key], conv_key, old_mat_dicts)
                        per_comp_flex.append(conv_key)
                    elif fsp_ineffective_per_comp[key] and old_fsp_ineffective_per_comp[key]:
                        conv_key = get_non_effective_conv(fsp_ineffective_per_comp[key], conv_key, old_mat_dicts)
                        conv_key = get_non_effective_conv(old_fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                        per_comp_flex.append(conv_key)
                    else:
                        per_comp_flex.append(conv_key)
        final_flex = np.prod(per_comp_flex, axis=0)
        final_flex[abs(final_flex) > 0] = 1
    else:
        for key in tqdm(fsp_effective_per_comp, desc="Network Components FAs"):
            if fsp_effective_per_comp[key]:
                # Apply all tensor convolutions and get 2D binary flexibility area
                conv_key = get_multi_conv_key_saving(fsp_effective_per_comp[key], mat_dicts, key, bus_nm, init_v,
                                                     init_load)
                if fsp_ineffective_per_comp[key]:
                    # Convolute 2D tensor-conv flex area with the innefective FSPs
                    conv_key = get_non_effective_multi_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                    per_comp_flex.append(conv_key)
                else:
                    per_comp_flex.append(conv_key)
        final_flex = per_comp_flex[0]
        for arr in per_comp_flex[1:]:
            final_flex = np.minimum(final_flex, arr)
        # final_flex = np.prod(per_comp_flex, axis=0)
        final_flex *= 1. / final_flex.max()
    # Apply axes
    t6_e = time.time()
    q_axes, p_axes = get_new_conv_axes2(axs_q, axs_p, len(pq_mat), len(pq_mat.T),
                                        float(init_pcc_pq[1]), float(init_pcc_pq[0]))

    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]

    if multi:
        conv_total = pd.DataFrame(final_flex, index=q_axis, columns=p_axis)
        inf = pd.DataFrame(pq_mat, index=q_axis, columns=p_axis)
        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        inf.loc[q_axis[q_index], p_axis[p_index]] = 2
    else:
        inf = None
        conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    t7_e = time.time()
    if small_fsp_prof and not multi:
        uncert_disc, uncert_cont, uncert_p_axs, uncert_q_axs = \
            get_uncertain_fa(pq_mat, final_flex, small_fsp_prof, dp, dq, small_fsp_init, p_axes, q_axes)
        uncert_q_axs = uncert_q_axs[::-1]
        uncert_p_axs = uncert_p_axs[::-1]
        discrete_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_disc)), index=uncert_q_axs, columns=uncert_p_axs)
        continuous_conv = pd.DataFrame(np.flipud(np.fliplr(uncert_cont)), index=uncert_q_axs, columns=uncert_p_axs)
        q_index, _ = find_value_close2list(uncert_q_axs, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(uncert_p_axs, float(init_pcc_pq[0]))
        discrete_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
        continuous_conv.loc[uncert_q_axs[-q_index], uncert_p_axs[-p_index]] = 4
    elif small_fsp_prof:
        assert Warning, "Warning: Simultaneous Uncertainty and Multiplicity currently not supported"
        discrete_conv = None
        continuous_conv = None
    else:
        discrete_conv = None
        continuous_conv = None
    t8_e = time.time()
    print(f"Duration distribution: \n    -Preparation = {t0_e - t0_s}s,\n    -Power Flows = {t1_e - t0_e}s,"
          f"\n    -Net. Component vs FSP dictionary = {t2_e - t1_e}s,\n    -Small FSPs = {t3_e - t2_e}s,"
          f"\n    -Effective FSPs per Component = {t4_e - t3_e}s,"
          f"\n    -Removal Safe Components = {t5_e - t4_e}s,\n    -(Tensor & 2D) Convolutions = {t6_e - t5_e}s,\n"
          f"    -Applying Axes and Init Point = {t7_e - t6_e}s,\n    -Small FSP Uncertainty calculation = {t8_e - t7_e}s")
    return conv_total, discrete_conv, continuous_conv, inf, q_axis[q_index], p_axis[p_index]


def adaptable_new_op(net, init_pcc_pq, small_fsp_prof, multi=False, minmax_v=[0.95, 1.05], max_l=100):
    #  -----------------------------------------Preparation------------------------------------------------------------
    t0_s = time.time()
    init_v, init_load = get_init_net_state(net)
    bus_nm, line_nm, trafo_nm = get_bus_line_and_trafo_names(net)
    t0_e = time.time()

    # ------------------------Load FSP effective dict------------------------------------------------------------------
    with open("drive/MyDrive/TCPlus/csv_results/adapt/FSP_effective_per_Comp.json", "r") as fp:
        old_vals = json.load(fp)
    fsp_effective_per_comp = old_vals['Effective']
    fsp_ineffective_per_comp = old_vals['Non-Effective']
    comp_shifts = old_vals['Shifts']
    ignore_comps = []
    for comp in init_v:
        if comp in comp_shifts:
            if minmax_v[0] - comp_shifts[comp][0] <= init_v[comp] <= minmax_v[1] - comp_shifts[comp][1]:
                ignore_comps.append(comp)
    for comp in init_load:
        if comp in comp_shifts:
            if max_l >= abs(init_load[comp] + comp_shifts[comp][1]) and max_l >= abs(
                    init_load[comp] + comp_shifts[comp][0]):
                ignore_comps.append(comp)

    p_shifts = np.load("drive/MyDrive/TCPlus/csv_results/adapt/p_axis.npy", allow_pickle=True)
    q_shifts = np.load("drive/MyDrive/TCPlus/csv_results/adapt/q_axis.npy", allow_pickle=True)

    # axs_shifts = np.load("drive/MyDrive/TCPlus/csv_results/adapt/pq_axes.npy", allow_pickle=True)
    mat_dicts = np.load("drive/MyDrive/TCPlus/csv_results/adapt/mat_dicts.npy", allow_pickle=True).item()
    pq_mat = np.load("drive/MyDrive/TCPlus/csv_results/adapt/pq_mat.npy", allow_pickle=True)
    # Add axs of new FSPs # todo: recompute pq_mat after retrieving tensors
    t2_e = time.time()
    # ------------------------ Apply convolutions-----------------------------------------------------------------------
    per_comp_flex = []
    # Find a way to remove components with min and max = 0 (0 std)

    for key in tqdm(fsp_effective_per_comp, desc="Network Components FAs"):
        if fsp_effective_per_comp[key] and key not in ignore_comps:
            # Apply all tensor convolutions and get 2D binary flexibility area
            conv_key = get_multi_conv_key_adapting_new_op(key, bus_nm, init_v, init_load,
                                                          min_v=minmax_v[0], max_v=minmax_v[1])
            if fsp_ineffective_per_comp[key]:
                # Convolute 2D tensor-conv flex area with the innefective FSPs
                conv_key = get_non_effective_multi_conv(fsp_ineffective_per_comp[key], conv_key, mat_dicts)
                per_comp_flex.append(conv_key)
            else:
                per_comp_flex.append(conv_key)
    final_flex = per_comp_flex[0]
    for arr in per_comp_flex[1:]:
        final_flex = np.minimum(final_flex, arr)
    final_flex[final_flex < 0.5] = 0
    # final_flex = np.prod(per_comp_flex, axis=0)
    final_flex *= 1. / final_flex.max()
    ff_one = final_flex.copy()
    ff_one[ff_one != 0] = 1
    final_flex += ff_one
    # Apply axes
    t6_e = time.time()
    q_axes = [q_vl + float(init_pcc_pq[1]) for q_vl in q_shifts]
    p_axes = [p_vl + float(init_pcc_pq[0]) for p_vl in p_shifts]

    q_axis = q_axes[::-1]
    p_axis = p_axes[::-1]

    if multi:
        conv_total = pd.DataFrame(final_flex, index=q_axis, columns=p_axis)
        inf = pd.DataFrame(pq_mat, index=q_axis, columns=p_axis)
        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        inf.loc[q_axis[q_index], p_axis[p_index]] = 2
    else:
        inf = None
        conv_total = pd.DataFrame(final_flex + pq_mat, index=q_axis, columns=p_axis)

        q_index, _ = find_value_close2list(q_axis, float(init_pcc_pq[1]))
        p_index, _ = find_value_close2list(p_axis, float(init_pcc_pq[0]))
        conv_total.loc[q_axis[q_index], p_axis[p_index]] = 3
    t7_e = time.time()
    if small_fsp_prof:
        assert Warning, "Warning: Uncertainty currently not supported"
        discrete_conv = None
        continuous_conv = None
    else:
        discrete_conv = None
        continuous_conv = None
    t8_e = time.time()
    print(f"Duration distribution: \n    -Preparation = {t0_e - t0_s}s,\n    -Load Data = {t2_e - t0_e}s,\n"
          f"    -(Tensor & 2D) Convolutions = {t6_e - t2_e}s,\n"
          f"    -Applying Axes and Init Point = {t7_e - t6_e}s,\n    "
          f"    -Small FSP Uncertainty calculation = {t8_e - t7_e}s")
    return conv_total, discrete_conv, continuous_conv, inf, q_index, p_index


def find_common_fsps_per_comp():
    # todo: find which components have similar sensitivity for similar shifts
    # Options: 1) On the dp,dq mat find the p0,q0 and check if neighbouring cells are similar (i.e. shifting both fsps results to similar changes)
    #          2) Find the paths from each FSP to each component, if all paths of 2 fsps pass through the same node -> aggregate
    print("nothing yet")
    return


def get_conv_key(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load):
    tot_conv_key = None
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        # print(f"Comp {comp} has pre fsps {pre_fsp}, and post fsps {post_fsp}")
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
                # conv_key = tensor_convolve_slide_window(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[fsp][comp])
            # conv_key = tensor_convolve_slide_window(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
            # conv_key = tensor_convolve_slide_window(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        if tot_conv_key is not None:
            tot_conv_key += conv_key
        else:
            tot_conv_key = conv_key
    ones_mat = tot_conv_key.copy()
    ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        # print(f"Comp {comp} Max {np.max(tot_conv_key)}, min {np.min(tot_conv_key)}, and init {init_v[comp]}")
        ones_mat[tot_conv_key >= 1.05 - round(init_v[comp], 3)] = 0
        ones_mat[tot_conv_key <= 0.95 - round(init_v[comp], 3)] = 0
        # print(f"Comp {comp} Max {np.max(tot_conv_key)}, min {np.min(tot_conv_key)}, and init {init_v[comp]}")
    else:
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
    # tot_conv_key[abs(tot_conv_key) > 0] = 1
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    final_mat[final_mat > 1] = 1
    # ones_mat[ones_mat > 0] = 1
    return final_mat  # , ones_mat


def get_conv_key_saving(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load):
    tot_conv_key = None
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        if tot_conv_key is not None:
            tot_conv_key += conv_key
        else:
            tot_conv_key = conv_key
    # tensor_save = tn.Tensor(np.float32(tot_conv_key), eps=1e-5)  # A tensor train decomposition
    tensor_save = tn.Tensor(float(tot_conv_key), eps=1e-5)  # A tensor train decomposition
    torch.save(tensor_save, f'csv_results/adapt/ttd{comp}.pt')
    ones_mat = tot_conv_key.copy()
    ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        ones_mat[tot_conv_key >= 1.05 - round(init_v[comp], 3)] = 0
        ones_mat[tot_conv_key <= 0.95 - round(init_v[comp], 3)] = 0
    else:
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    final_mat[final_mat > 1] = 1
    return final_mat


def get_conv_key_adapting(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load):
    try:
        pre_tensor = torch.load(f'csv_results/adapt/ttd{comp}.pt').torch().cpu().numpy()
    except:
        pre_tensor = None

    tot_conv_key = None
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        if tot_conv_key is not None:
            tot_conv_key += conv_key
        else:
            tot_conv_key = conv_key
    ones_mat = tot_conv_key.copy()
    ones_mat[abs(ones_mat) > 0] = 1
    if pre_tensor != None:
        ones_pre_tensor = pre_tensor.copy()
        ones_pre_tensor[abs(ones_pre_tensor) > 0] = 1

        tot_conv_key = tensor_convolve_nd(ones_pre_tensor, tot_conv_key) + tensor_convolve_nd(pre_tensor, ones_mat)
        ones_mat = tot_conv_key.copy()
        ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        ones_mat[tot_conv_key >= 1.05 - round(init_v[comp], 3)] = 0
        ones_mat[tot_conv_key <= 0.95 - round(init_v[comp], 3)] = 0
    else:
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    final_mat[final_mat > 1] = 1
    return final_mat


def get_conv_key_adapting_new_op(comp, bus_nm, init_v, init_load):
    tot_conv_key = torch.load(f'csv_results/adapt/ttd{comp}.pt').torch().cpu().numpy()
    ones_mat = tot_conv_key.copy()
    ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        ones_mat[tot_conv_key >= 1.05 - round(init_v[comp], 3)] = 0
        ones_mat[tot_conv_key <= 0.95 - round(init_v[comp], 3)] = 0
    else:
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    final_mat[final_mat > 1] = 1
    return final_mat


def get_multi_conv_key_adapting_new_op(comp, bus_nm, init_v, init_load, min_v, max_v):
    tot_conv_key = torch.load(f'drive/MyDrive/TCPlus/csv_results/adapt/ttd{comp}.pt').torch()
    ones_conv_key = torch.load(f'drive/MyDrive/TCPlus/csv_results/adapt/ttd_ones{comp}.pt').torch()

    if comp in bus_nm:
        mask = (max_v >= tot_conv_key + init_v[comp]) & (tot_conv_key + init_v[comp] >= min_v)
        ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
    else:
        mask = (100 >= tot_conv_key + init_load[comp]) & (tot_conv_key + init_load[comp] >= -100)
        ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    if len(alphabet) == 2:
        final_mat = ones_mat  # np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    return final_mat


def adapt_only_old_effective(tot_conv_key, comp, bus_nm, init_v, init_load):
    ones_mat = tot_conv_key.copy()
    ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        ones_mat[tot_conv_key >= 1.05 - round(init_v[comp], 3)] = 0
        ones_mat[tot_conv_key <= 0.95 - round(init_v[comp], 3)] = 0
    else:
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    final_mat[final_mat > 1] = 1
    return final_mat


def get_ttd_conv_key(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load):
    tot_conv_key = None
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        # print(f"Comp {comp} has pre fsps {pre_fsp}, and post fsps {post_fsp}")
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
                # conv_key = tensor_convolve_slide_window(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[fsp][comp])
            # conv_key = tensor_convolve_slide_window(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
            # conv_key = tensor_convolve_slide_window(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        if tot_conv_key is not None:
            # tot_conv_key += tn.Tensor(conv_key.astype(np.float32), ranks_tt=3)  # A tensor train decomposition
            tot_conv_key += tn.Tensor(float(conv_key), ranks_tt=3)  # A tensor train decomposition
        else:
            # tot_conv_key = tn.Tensor(conv_key.astype(np.float32), ranks_tt=3)  # A tensor train decomposition
            tot_conv_key = tn.Tensor(float(conv_key), ranks_tt=3)  # A tensor train decomposition
    ones_mat = tot_conv_key.torch()
    tensor_tot = tot_conv_key.torch()
    ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        # print(f"Comp {comp} Max {np.max(tot_conv_key)}, min {np.min(tot_conv_key)}, and init {init_v[comp]}")
        ones_mat[tensor_tot >= 1.05 - round(init_v[comp], 3)] = 0
        ones_mat[tensor_tot <= 0.95 - round(init_v[comp], 3)] = 0
        # print(f"Comp {comp} Max {np.max(tot_conv_key)}, min {np.min(tot_conv_key)}, and init {init_v[comp]}")
    else:
        ones_mat[tensor_tot >= 100 - init_load[comp]] = 0
        ones_mat[tensor_tot >= 100 - init_load[comp]] = 0
    # tot_conv_key[abs(tot_conv_key) > 0] = 1
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    final_mat[final_mat > 1] = 1
    # ones_mat[ones_mat > 0] = 1
    return final_mat


def get_fast_conv_key(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load):
    tot_conv_key = None
    s1 = time.time()
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                # conv_key = tensor_convolve_nd_clean(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
                conv_key = tensor_convolve_nd_tf(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            # conv_key = tensor_convolve_nd_clean(conv_key, mat_dicts[fsp][comp])
            conv_key = tensor_convolve_nd_tf(conv_key, mat_dicts[fsp][comp])

        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            # conv_key = tensor_convolve_nd_clean(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd_tf(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        s2 = time.time()
        print(f"Time for fsp {fsp}: {s2 - s1}")
        if tot_conv_key is not None:
            tot_conv_key += conv_key
        else:
            tot_conv_key = conv_key
        s3 = time.time()
        print(f"Time to add fsp {fsp}: {s3 - s2}")
        s1 = s3

    # ones_mat = tot_conv_key.copy()
    ones_mat = tf.identity(tot_conv_key)
    # ones_mat[abs(ones_mat) > 0.] = 1.
    ones_mat = tf.cast(tf.sign(tf.cast(ones_mat, tf.float32)), tf.float32) * 1

    if comp in bus_nm:

        # ones_mat[tot_conv_key >= 1.05-round(init_v[comp], 3)] = 0
        # ones_mat[tot_conv_key <= 0.95-round(init_v[comp], 3)] = 0
        ones_mat = tf.where(tot_conv_key >= 1.05 - init_v[comp], tf.zeros_like(ones_mat), ones_mat)
        ones_mat = tf.where(tot_conv_key <= 1.05 - init_v[comp], tf.zeros_like(ones_mat), ones_mat)
    else:
        # ones_mat[tot_conv_key >= 100-init_load[comp]] = 0
        # ones_mat[tot_conv_key >= 100-init_load[comp]] = 0
        ones_mat = tf.where(tot_conv_key >= 100 - init_load[comp], tf.zeros_like(ones_mat), ones_mat)

    # tot_conv_key[abs(tot_conv_key) > 0] = 1
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
    if len(alphabet) == 2:
        # final_mat = np.flipud(np.fliplr(ones_mat))
        final_mat = tf.reverse(ones_mat, axis=[0, 1])
    else:
        # final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
        final_mat = tf.reverse(np.einsum(f'{alphabet}->ab', ones_mat), axis=[0, 1])
    # final_mat[final_mat > 1] = 1
    final_mat = tf.where(final_mat > 1, tf.zeros_like(final_mat), final_mat)
    return final_mat


def get_multi_conv_key(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load):
    tot_conv_key = None
    s1 = time.time()
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        s2 = time.time()
        print(f"Time for fsp {fsp}: {s2 - s1}")
        if tot_conv_key is not None:
            # tot_conv_key += conv_key
            tot_conv_key = torch.add(tot_conv_key, torch.Tensor(conv_key))
        else:
            # tot_conv_key = conv_key
            tot_conv_key = torch.Tensor(conv_key)

        s3 = time.time()
        print(f"Time to add fsp {fsp}: {s3 - s2}")
        s1 = s2
    tot_conv_key = tot_conv_key.cpu().numpy()
    ones_mat = tot_conv_key.copy()
    ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        ones_mat[tot_conv_key >= 1.05 - round(init_v[comp], 3)] = 0
        ones_mat[tot_conv_key <= 0.95 - round(init_v[comp], 3)] = 0
    else:
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
        ones_mat[tot_conv_key >= 100 - init_load[comp]] = 0
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    return final_mat


def get_multi_conv_torch(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load, max_v=1.05, min_v=0.95):
    tot_conv_key = None
    # for key in mat_dicts:
    #    mat_dicts[key]['PQ'] = torch.Tensor(mat_dicts[key]['PQ'])
    #    mat_dicts[key][comp] = torch.Tensor(mat_dicts[key][comp])
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        if tot_conv_key is not None:
            tot_conv_key = torch.add(tot_conv_key, conv_key)
        else:
            tot_conv_key = conv_key
        if idx == 0:
            ones_conv_key = mat_dicts[fsps_of_comp[0]]['PQ']
            for fsp in fsps_of_comp[1:]:
                ones_conv_key = tensor_convolve_nd_torch(ones_conv_key, mat_dicts[fsp]['PQ'])
    st = time.time()

    # tot_conv_key = tot_conv_key.numpy()
    # ones_mat = tot_conv_key.copy()
    # ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        mask = (max_v >= tot_conv_key + init_v[comp]) & (tot_conv_key + init_v[comp] >= min_v)
        # ones_mat = ones_mat = torch.where(mask, 1, 0).numpy()
        ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
    else:
        mask = (100 >= tot_conv_key + init_load[comp]) & (tot_conv_key + init_load[comp] >= -100)
        # ones_mat = ones_mat = torch.where(mask, 1, 0).numpy()
        ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    return final_mat


def correlate(fsps_of_comp, mat_dicts, comp):
    new_fsps_of_comp = []
    while len(new_fsps_of_comp) < 4:
        best_cc = -1
        new_comb = ''
        for fsp1 in fsps_of_comp:
            for fsp2 in fsps_of_comp:
                if fsp1 != fsp2:
                    if fsp1.shape[0] > 2 and fsp1.shape[1] > 2 and fsp2.shape[0] > 2 and fsp2.shape[1] > 2:
                        compareew = fsp1


def get_multi_conv_torch_split(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load, sim_dict, init_ids,
                               max_v=1.05, min_v=0.95, no_max=5):
    tot_conv_key = None
    new_pairs = {}
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    torch.set_default_device(device)
    while len(fsps_of_comp) >= no_max:
        min_pair = []
        min_dist = 1000
        for idx, fsp in enumerate(fsps_of_comp):
            if fsp in list(sim_dict.keys()):
                if sim_dict[fsp]["min"][0] < min_dist and sim_dict[fsp]["min"][1] in fsps_of_comp:
                    min_dist = sim_dict[fsp]["min"][0]
                    min_pair = [fsp, sim_dict[fsp]["min"][1]]
                elif sim_dict[fsp]["min"][0] < min_dist:
                    for pair in new_pairs:
                        spl_txt = pair.split(":+:")
                        for pre_comb_fsp in spl_txt:
                            if pre_comb_fsp == sim_dict[fsp]["min"][1]:
                                min_pair = [fsp, pair]
                                min_dist = sim_dict[fsp]["min"][0]
            """
            else:
                spl_txt = fsp.split(":+:")
                for pre_comb_fsp in spl_txt:
                    print(f"Here 3 {sim_dict[pre_comb_fsp]['min'][1]}")
                    if sim_dict[pre_comb_fsp]["min"][0] < min_dist and sim_dict[pre_comb_fsp]["min"][1] in fsps_of_comp:
                        print("Here 4")
                        min_dist = sim_dict[pre_comb_fsp]["min"][0]
                        min_pair = [fsp, sim_dict[pre_comb_fsp]["min"][1]]
            """
        conv_merge0 = tensor_convolve_nd_torch(mat_dicts[min_pair[1]][comp], mat_dicts[min_pair[0]]['PQ'])
        conv_merge1 = tensor_convolve_nd_torch(mat_dicts[min_pair[1]]['PQ'], mat_dicts[min_pair[0]][comp])
        conv_merge = conv_merge0 + conv_merge1

        dims = len(conv_merge.shape)
        alphabet = string.ascii_lowercase[:dims]
        conv_merge = torch.einsum(f'{alphabet}->ab', conv_merge)
        if True:
            delta_mat1 = torch.zeros_like(mat_dicts[min_pair[1]]['PQ'])
            delta_mat1[init_ids[min_pair[1]][0], init_ids[min_pair[1]][1]] = 1
            tmp1 = torch.clone(mat_dicts[min_pair[0]]['PQ'])
            tmp2 = delta_mat1
            extra_mat_tt1 = torch.Tensor(signal.convolve2d(tmp1.cpu(), tmp2.cpu()))
            delta_mat2 = torch.zeros_like(mat_dicts[min_pair[0]]['PQ'])
            delta_mat2[init_ids[min_pair[0]][0], init_ids[min_pair[0]][1]] = 1
            tmp1 = torch.clone(mat_dicts[min_pair[1]]['PQ'])
            tmp3 = delta_mat2
            extra_mat_tt2 = torch.Tensor(signal.convolve2d(tmp1.cpu(), tmp3.cpu()))
            extra_mat_tt = extra_mat_tt1 + extra_mat_tt2
            extra_mat_tt[extra_mat_tt > 0.5] = 1

            init_ids[str(min_pair[0]) + ":+:" + str(min_pair[1])] = list(
                np.transpose(np.nonzero(signal.convolve2d(tmp2.cpu(), tmp3.cpu())))[0])

        elif mat_dicts[min_pair[0]]['PQ'].shape[0] > mat_dicts[min_pair[1]]['PQ'].shape[0]:
            # min_idx, min_jdx = np.nonzero(mat_dicts[min_pair[1]][comp]).argmin() // mat_dicts[min_pair[1]][comp].shape[1], \
            #                   np.nonzero(mat_dicts[min_pair[1]][comp]).argmin() % mat_dicts[min_pair[1]][comp].shape[1]
            delta_mat = torch.zeros_like(mat_dicts[min_pair[1]]['PQ'])
            delta_mat[init_ids[min_pair[1]][0], init_ids[min_pair[1]][1]] = 1
            tmp1 = torch.clone(mat_dicts[min_pair[0]]['PQ'])
            tmp2 = delta_mat
            extra_mat_tt = torch.Tensor(signal.convolve2d(tmp1.cpu(), tmp2.cpu()))
        else:
            delta_mat = torch.zeros_like(mat_dicts[min_pair[0]]['PQ'])
            delta_mat[init_ids[min_pair[0]][0], init_ids[min_pair[0]][1]] = 1
            tmp1 = delta_mat
            tmp2 = torch.clone(mat_dicts[min_pair[1]]['PQ'])
            extra_mat_tt = torch.Tensor(signal.convolve2d(tmp1.cpu(), tmp2.cpu()))

        tmp1 = torch.clone(mat_dicts[min_pair[0]]['PQ'])
        tmp2 = torch.clone(mat_dicts[min_pair[1]]['PQ'])

        pq_mat_tt = torch.Tensor(signal.convolve2d(tmp1.cpu(), tmp2.cpu())).to(device)

        new_mat = torch.div(conv_merge.to(device), pq_mat_tt.to(device) + extra_mat_tt.to(device))
        new_mat = torch.nan_to_num(new_mat)

        new_fsps_of_comp = []
        for fspp in fsps_of_comp:
            if fspp not in min_pair:
                new_fsps_of_comp.append(fspp)
        new_fsps_of_comp.append(str(min_pair[0]) + ":+:" + str(min_pair[1]))
        fsps_of_comp = new_fsps_of_comp

        pq_new_matt = pq_mat_tt.clone()
        pq_new_matt[pq_mat_tt > 0.1] = 1
        mat_dicts[str(min_pair[0]) + ":+:" + str(min_pair[1])] = {'PQ': pq_new_matt}
        mat_dicts[str(min_pair[0]) + ":+:" + str(min_pair[1])][comp] = new_mat
        new_pairs[str(min_pair[0]) + ":+:" + str(min_pair[1])] = pq_mat_tt

    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd_torch_half(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd_torch_half(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd_torch_half(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        # conv_key = tn.Tensor(conv_key, eps=1e-3)
        if tot_conv_key is not None:
            tot_conv_key = torch.add(tot_conv_key, conv_key)
        else:
            tot_conv_key = conv_key
        if idx == 0:
            ones_conv_key = mat_dicts[fsps_of_comp[0]]['PQ']
            for fsp in fsps_of_comp[1:]:
                if fsp not in list(new_pairs.keys()):
                    ones_conv_key = tensor_convolve_nd_torch_half(ones_conv_key, mat_dicts[fsp]['PQ'])
                else:
                    ones_conv_key = tensor_convolve_nd_torch_half(ones_conv_key, new_pairs[fsp])

    # tot_conv_key = torch.Tensor(tot_conv_key)
    st = time.time()

    # tot_conv_key = tot_conv_key.numpy()
    # ones_mat = tot_conv_key.copy()
    # ones_mat[abs(ones_mat) > 0] = 1
    if comp in bus_nm:
        mask = (max_v >= tot_conv_key + init_v[comp]) & (tot_conv_key + init_v[comp] >= min_v)
        # ones_mat = ones_mat = torch.where(mask, 1, 0).numpy()
        ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
    else:
        mask = (100 >= tot_conv_key + init_load[comp]) & (tot_conv_key + init_load[comp] >= -100)
        # ones_mat = ones_mat = torch.where(mask, 1, 0).numpy()
        ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    return final_mat


def get_multi_conv_key_saving(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load, max_v=1.05, min_v=0.95):
    tot_conv_key = None
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        if tot_conv_key is not None:
            tot_conv_key += conv_key
        else:
            tot_conv_key = conv_key
        if idx == 0:
            ones_conv_key = mat_dicts[fsps_of_comp[0]]['PQ']
            for fsp in fsps_of_comp[1:]:
                ones_conv_key = tensor_convolve_nd_torch(ones_conv_key, mat_dicts[fsp]['PQ'])
    tmp = np.float32(tot_conv_key)
    tensor_save = tn.Tensor(tmp, eps=1e-3)  # A tensor train decomposition
    torch.save(tensor_save, f'drive/MyDrive/TCPlus/csv_results/adapt/ttd{comp}.pt')
    tmp = np.float32(ones_conv_key)
    tensor_save = tn.Tensor(tmp, eps=1e-3)  # A tensor train decomposition
    torch.save(tensor_save, f'drive/MyDrive/TCPlus/csv_results/adapt/ttd_ones{comp}.pt')

    if comp in bus_nm:
        mask = (max_v >= tot_conv_key + init_v[comp]) & (tot_conv_key + init_v[comp] >= min_v)
        ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
    else:
        mask = (100 >= tot_conv_key + init_load[comp]) & (tot_conv_key + init_load[comp] >= -100)
        ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
    dims = len(tot_conv_key.shape)
    alphabet = string.ascii_lowercase[:dims]
    # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
    if len(alphabet) == 2:
        final_mat = np.flipud(np.fliplr(ones_mat))
    else:
        final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
    return final_mat


def get_multi_conv_key_with_delta(fsps_of_comp, mat_dicts, comp, bus_nm, init_v, init_load, comp_non_lin_fsp, pq_steps,
                                  min_v, max_v):
    tot_conv_key = None
    for idx, fsp in enumerate(fsps_of_comp):
        pre_fsp = fsps_of_comp[:idx]
        post_fsp = fsps_of_comp[idx + 1:]
        if pre_fsp:
            conv_key = mat_dicts[pre_fsp.pop(0)]['PQ']
            while pre_fsp:
                conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[pre_fsp.pop(0)]['PQ'])
            conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[fsp][comp])
        else:
            conv_key = mat_dicts[fsp][comp]
        while post_fsp:
            conv_key = tensor_convolve_nd_torch(conv_key, mat_dicts[post_fsp.pop(0)]['PQ'])
        if tot_conv_key is not None:
            tot_conv_key = torch.add(tot_conv_key, conv_key)
            # tot_conv_key += conv_key
        else:
            tot_conv_key = conv_key
        if idx == 0:
            ones_conv_key = mat_dicts[fsps_of_comp[0]]['PQ']
            for fsp in fsps_of_comp[1:]:
                ones_conv_key = tensor_convolve_nd_torch(ones_conv_key, mat_dicts[fsp]['PQ'])
    if len(comp_non_lin_fsp) == 0:
        if comp in bus_nm:
            mask = (max_v >= tot_conv_key + init_v[comp]) & (tot_conv_key + init_v[comp] >= min_v)
            ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
        else:
            mask = (100 >= tot_conv_key + init_load[comp]) & (tot_conv_key + init_load[comp] >= -100)
            ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
        dims = len(tot_conv_key.shape)
        alphabet = string.ascii_lowercase[:dims]
        # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
        if len(alphabet) == 2:
            final_mat = np.flipud(np.fliplr(ones_mat))
        else:
            final_mat = np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))
        return final_mat
    else:
        shapes = []
        for idx, fsp in enumerate(comp_non_lin_fsp):
            mat_list = mat_dicts[fsp]
            # Each list has the form [{dp:, dq:, Bus #: .., Line ...}, {dp: .....},...]
            for shift in mat_list:
                if comp in bus_nm:
                    mask = (max_v - shift[comp] >= tot_conv_key + init_v[comp]) \
                           & (tot_conv_key + init_v[comp] >= min_v - shift[comp])
                    ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
                else:
                    mask = (100 - shift[comp] >= tot_conv_key + init_load[comp]) \
                           & (tot_conv_key + init_load[comp] >= -100 - shift[comp])
                    ones_mat = torch.mul(torch.where(mask, 1, 0), ones_conv_key).cpu().numpy()
                dims = len(tot_conv_key.shape)
                alphabet = string.ascii_lowercase[:dims]
                # ones_mat = np.flipud(np.fliplr(np.einsum('ij...', ones_mat)))
                if len(alphabet) == 2:
                    shapes.append([float(shift['dp']), float(shift['dq']), np.flipud(np.fliplr(ones_mat))])
                else:
                    shapes.append([float(shift['dp']), float(shift['dq']),
                                   np.flipud(np.fliplr(np.einsum(f'{alphabet}->ab', ones_mat)))])
        return combine_shapes(shapes, pq_steps)


def combine_shapes(shapes, pq_steps):
    #                   +  -
    generic_p_shifts = [0, 0]
    generic_q_shifts = [0, 0]
    # Find total padding of pixels (gen_p_sh[0] = right, gen_p_sh[1] = left, gen_q_sh[0] = top, gen_q_sh[1] = bottom)
    for shape in shapes:
        p_pixels = round(shape[0] / pq_steps[0])
        q_pixels = round(shape[1] / pq_steps[1])
        if p_pixels > 0:
            generic_p_shifts[0] += p_pixels
        else:
            generic_p_shifts[1] += p_pixels
        if q_pixels > 0:
            generic_q_shifts[0] += q_pixels
        else:
            generic_q_shifts[1] += q_pixels
    padded_arrays = []
    for shape in shapes:
        specific_p_shifts = [generic_p_shifts[0] - round(shape[0] / pq_steps[0]),
                             -generic_p_shifts[1] + round(shape[0] / pq_steps[0])]
        specific_q_shifts = [generic_q_shifts[0] - round(shape[1] / pq_steps[1]),
                             -generic_q_shifts[1] + round(shape[1] / pq_steps[1])]
        padded_arrays.append(np.pad(shape[2], ((specific_q_shifts[0], specific_q_shifts[1]),
                                               (specific_p_shifts[0], specific_p_shifts[1]))))
    padded_arrays = np.array(padded_arrays)
    return np.einsum('ijk->jk', padded_arrays)


def combine_shapes_const_flex(shapes, pq_steps, flex):
    #                   +  -
    generic_p_shifts = [0, 0]
    generic_q_shifts = [0, 0]
    # Find total padding of pixels (gen_p_sh[0] = right, gen_p_sh[1] = left, gen_q_sh[0] = top, gen_q_sh[1] = bottom)
    for shape in shapes:
        p_pixels = round(shape[0] / pq_steps[0])
        q_pixels = round(shape[1] / pq_steps[1])
        if p_pixels > 0:
            generic_p_shifts[0] += p_pixels
        else:
            generic_p_shifts[1] += p_pixels
        if q_pixels > 0:
            generic_q_shifts[0] += q_pixels
        else:
            generic_q_shifts[1] += q_pixels
    padded_arrays = []
    for shape in shapes:
        specific_p_shifts = [generic_p_shifts[0] - round(shape[0] / pq_steps[0]),
                             -generic_p_shifts[1] + round(shape[0] / pq_steps[0])]
        specific_q_shifts = [generic_q_shifts[0] - round(shape[1] / pq_steps[1]),
                             -generic_q_shifts[1] + round(shape[1] / pq_steps[1])]
        # todo: check these pads
        if shape[2] == 1:
            padded_arrays.append(np.pad(flex, ((specific_q_shifts[1], specific_q_shifts[0]),
                                               (specific_p_shifts[1], specific_p_shifts[0]))))
        else:
            padded_arrays.append(np.pad(np.zeros_like(flex), ((specific_q_shifts[1], specific_q_shifts[0]),
                                                              (specific_p_shifts[1], specific_p_shifts[0]))))
    padded_arrays = np.array(padded_arrays)
    tmp = np.einsum('ijk->jk', padded_arrays)
    return tmp


def get_non_effective_conv(non_effective_fsps, effective_conv, mat_dicts):
    pq_mat = mat_dicts[non_effective_fsps.pop(0)]['PQ']
    for fsp in non_effective_fsps:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[fsp]['PQ'])
        pq_mat[pq_mat > 0.1] = 1
    # return np.flipud(np.fliplr(signal.convolve2d(pq_mat, np.flipud(np.fliplr(effective_conv)))))
    return signal.convolve2d(np.flipud(np.fliplr(pq_mat)), effective_conv)


def get_result_for_0_effective(non_effective_fsps, mat_dicts):
    pq_mat = mat_dicts[non_effective_fsps.pop(0)]['PQ']
    for fsp in non_effective_fsps:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[fsp]['PQ'])
        pq_mat[pq_mat > 0.1] = 1
    # return np.flipud(np.fliplr(signal.convolve2d(pq_mat, np.flipud(np.fliplr(effective_conv)))))
    return np.flipud(np.fliplr(pq_mat))


def get_multi_result_for_0_effective(non_effective_fsps, mat_dicts):
    pq_mat = mat_dicts[non_effective_fsps.pop(0)]['PQ'].cpu()
    for fsp in non_effective_fsps:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[fsp]['PQ'].cpu())
    return np.flipud(np.fliplr(pq_mat))


def get_non_effective_multi_conv(non_effective_fsps, effective_conv, mat_dicts):
    pq_mat = mat_dicts[non_effective_fsps.pop(0)]['PQ'].cpu()
    for fsp in non_effective_fsps:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[fsp]['PQ'].cpu())
    return signal.convolve2d(np.flipud(np.fliplr(pq_mat)), effective_conv)


def get_non_effective_multi_conv_with_delta(non_effective_fsps, effective_conv, mat_dicts, non_eff_non_lin_fsps,
                                            pq_steps):
    pq_mat = mat_dicts[non_effective_fsps.pop(0)]['PQ'].cpu()
    for fsp in non_effective_fsps:
        pq_mat = signal.convolve2d(pq_mat, mat_dicts[fsp]['PQ'].cpu())
    shapes = []
    for fsp in non_eff_non_lin_fsps:
        mat_list = non_eff_non_lin_fsps[fsp]
        for shift in mat_list:
            shapes.append([float(shift['dp']), float(shift['dq']), pq_mat])
    if len(shapes) > 0:
        final_mat = combine_shapes(shapes, pq_steps)
        return signal.convolve2d(np.flipud(np.fliplr(final_mat)), effective_conv)
    else:
        return signal.convolve2d(np.flipud(np.fliplr(pq_mat)), effective_conv)


def get_result_for_0_effective_with_delta(final_flex, non_lin_eff_fsp_per_comp,
                                          non_lin_ineff_fsp_per_comp, pq_steps, bus_nm, init_v, init_l, mat_dicts):
    flexes = []
    for comp in non_lin_eff_fsp_per_comp:
        shapes = []
        if non_lin_eff_fsp_per_comp[comp]:
            for fsp in non_lin_eff_fsp_per_comp[comp]:
                mat_list = mat_dicts[fsp]
                for shift in mat_list:
                    if comp in bus_nm:
                        if 1.05 > init_v[comp] + shift[comp] > 0.95:
                            shapes.append([float(shift['dp']), float(shift['dq']), 1])
                        else:
                            shapes.append([float(shift['dp']), float(shift['dq']), 0])
                    else:
                        if 100 > init_l[comp] + shift[comp]:
                            shapes.append([float(shift['dp']), float(shift['dq']), 1])
                        else:
                            shapes.append([float(shift['dp']), float(shift['dq']), 0])
            for fsp in non_lin_ineff_fsp_per_comp[comp]:
                # mat_list = non_lin_eff_fsp_per_comp[comp][fsp]
                mat_list = mat_dicts[fsp]
                for shift in mat_list:
                    shapes.append([float(shift['dp']), float(shift['dq']), 1])
            if len(shapes) > 0:
                flexes.append(combine_shapes_const_flex(shapes, pq_steps, final_flex))
    if len(flexes) == 0:
        shapes = []
        for fsp in non_lin_ineff_fsp_per_comp[comp]:
            # mat_list = non_lin_ineff_fsp_per_comp[fsp]
            mat_list = mat_dicts[fsp]
            for shift in mat_list:
                shapes.append([float(shift['dp']), float(shift['dq']), 1])
        if shapes:
            shapes = np.array(shapes)
            return np.flipud(np.fliplr(combine_shapes_const_flex(shapes, pq_steps, final_flex)))
        else:
            return np.flipud(np.fliplr(final_flex))
    else:
        flexes = np.array(flexes)
        # TODO: Check if this needs to be min instead of prod
        final_flex = flexes[0]
        for arr in flexes[1:]:
            final_flex = np.minimum(final_flex, arr)
        return final_flex


def get_all_tensor_ones(sens_dict, mat_dicts):
    # if len sens_dict[key] >= 2 (no need for HD Tensors)
    seen_comps = []
    tensors = {}
    for key in sens_dict:
        if len(sens_dict[key]) == 3:
            if sens_dict[key][0] + sens_dict[key][1] not in seen_comps:
                seen_comps.append(sens_dict[key][0] + sens_dict[key][1])
                tensors[sens_dict[key][0] + sens_dict[key][1]] = tensor_convolve_nd(mat_dicts[sens_dict[key][0]]['PQ'],
                                                                                    mat_dicts[sens_dict[key][1]]['PQ'])
                tensors[sens_dict[key][0] + sens_dict[key][1]][tensors[sens_dict[key][0] + sens_dict[key][1]] > 0.1] = 1

    for key in sens_dict:
        if len(sens_dict[key]) == 4:
            if sens_dict[key][0] + sens_dict[key][1] not in seen_comps:
                seen_comps.append(sens_dict[key][0] + sens_dict[key][1])
                tensors[sens_dict[key][0] + sens_dict[key][1]] = tensor_convolve_nd(mat_dicts[sens_dict[key][0]]['PQ'],
                                                                                    mat_dicts[sens_dict[key][1]]['PQ'])
                tensors[sens_dict[key][0] + sens_dict[key][1]][tensors[sens_dict[key][0] + sens_dict[key][1]] > 0.1] = 1
            if sens_dict[key][0] + sens_dict[key][1] + sens_dict[key][2] not in seen_comps:
                seen_comps.append(sens_dict[key][0] + sens_dict[key][1] + sens_dict[key][2])
                tensors[sens_dict[key][0] + sens_dict[key][1] + sens_dict[key][2]] = \
                    tensor_convolve_nd(tensors[sens_dict[key][0] + sens_dict[key][1]],
                                       mat_dicts[sens_dict[key][2]]['PQ'])
                tensors[sens_dict[key][0] + sens_dict[key][1] + sens_dict[key][2]] \
                    [tensors[sens_dict[key][0] + sens_dict[key][1] + sens_dict[key][2]] > 0.1] = 1
    return tensors


def get_tensor_ones_of_comp_list(comp_list, mat_dicts):
    # UNUSED
    pq_mat = mat_dicts[comp_list[0]]['PQ']
    for idx, elmnt in enumerate(comp_list[1:]):
        pq_mat = tensor_convolve_nd(pq_mat, mat_dicts[elmnt]['PQ'])
    pq_mat[pq_mat > 0.1] = 1
    return pq_mat


def get_new_conv_axes2(list_of_rows, list_of_columns, conv_q_len, conv_p_len, q, p, exs=0):
    min_rows = q
    max_rows = q
    for row in list_of_rows:
        min_rows += min(0, float(min(row)) - q)
        max_rows += max(0, float(max(row)) - q)
    min_cols = p
    max_cols = p
    for col in list_of_columns:
        min_cols += min(0, float(min(col)) - p)
        max_cols += max(0, float(max(col)) - p)
    rows = np.linspace(min_rows, max_rows, num=conv_q_len)
    cols = np.linspace(min_cols, max_cols, num=conv_p_len)

    return rows, cols


def run_all_flex_areas(settings, net, pq_profiles):
    max_curr = settings.max_curr
    max_volt = settings.max_volt
    min_volt = settings.min_volt

    t_start_run_mc_pf = time.time()
    result_dict = {}
    for key in tqdm(pq_profiles, desc="FSP Flexibilities Completed:"):
        fsp_type = 'None'
        fsp_idx = -1
        result_dict[key] = pd.DataFrame()
        if 'Load' not in key:
            for idx, gen in enumerate(net.sgen.iterrows()):
                if gen[1]['name'] == key:
                    fsp_idx = idx
                    fsp_type = 'Sgen'
        else:
            for idx, load in enumerate(net.load.iterrows()):
                if load[1]['name'] == key:
                    fsp_idx = idx
                    fsp_type = 'Load'
        if fsp_type == 'None':
            assert False, f"Cannot detect FSP name {key}"
        for profile in pq_profiles[key]:
            net = update_conv_pqs(net, fsp_idx=fsp_idx, fsp_type=fsp_type, profile=profile)
            try:
                pp.runpp(net)
                pq_value = [float(net.res_ext_grid['p_mw']), float(net.res_ext_grid['q_mvar'])]
                if check_voltage_limits(net.res_bus['vm_pu'], max_volt, min_volt) and \
                        check_line_current_limits(net, max_curr) and check_trafo_current_limits(net,
                                                                                                max_curr):  # True -> Flexible, False -> Limit passed
                    result_dict[key] = result_dict[key].append({'p': pq_value[0], 'q': pq_value[1], 'flex': 1},
                                                               ignore_index=True)
                else:
                    result_dict[key] = result_dict[key].append({'p': pq_value[0], 'q': pq_value[1], 'flex': 0},
                                                               ignore_index=True)
            except:
                print(f"Power flow did not converge for profile {profile}")
        # todo: Save flexibilities from each resource to apply convolution
    t_stop_run_mc_pf = time.time()
    print(f"{settings.no_samples} MC Power flows needed {t_stop_run_mc_pf - t_start_run_mc_pf} seconds")
    return result_dict, t_stop_run_mc_pf - t_start_run_mc_pf


def run_all_tensor_flex_areas(net, pq_profiles, bus_nm, line_nm, trafo_nm, init_v, init_load):
    t_start_run_mc_pf = time.time()
    result_dict = {}
    std_dict = {}
    for key in tqdm(pq_profiles, desc="FSP Flexibilities Completed"):
        fsp_type = 'None'
        fsp_idx = -1
        result_dict[key] = pd.DataFrame()
        if 'Load' not in key and 'load' not in key:
            for idx, gen in enumerate(net.sgen.iterrows()):
                if gen[1]['name'] == key:
                    fsp_idx = idx
                    fsp_type = 'Sgen'
        else:
            for idx, load in enumerate(net.load.iterrows()):
                if load[1]['name'] == key:
                    fsp_idx = idx
                    fsp_type = 'Load'
        if fsp_type == 'None':
            assert False, f"Cannot detect FSP name {key}"
        for profile in pq_profiles[key]:
            net = update_conv_pqs(net, fsp_idx=fsp_idx, fsp_type=fsp_type, profile=profile)
            try:
                pp.runpp(net)
                tmp_dict = {'p': float(net.res_ext_grid['p_mw'].iloc[0]),
                            'q': float(net.res_ext_grid['q_mvar'].iloc[0])}

                for i, nm in enumerate(bus_nm):
                    tmp_dict[nm] = float(net.res_bus['vm_pu'].iloc[i] - init_v[nm])
                for i, nm in enumerate(line_nm):
                    tmp_dict[nm] = float(net.res_line['loading_percent'].iloc[i] - init_load[nm])
                for i, nm in enumerate(trafo_nm):
                    tmp_dict[nm] = float(net.res_trafo['loading_percent'].iloc[i] - init_load[nm])
                result_dict[key] = result_dict[key].append(tmp_dict, ignore_index=True)
            except:
                print(f"Power flow did not converge for profile {profile}")
        net = update_conv_pqs(net, fsp_idx=fsp_idx, fsp_type=fsp_type, profile=pq_profiles[key][0])
        std_dict[key] = {'std': result_dict[key].std().drop(['p', 'q']),
                         'min': result_dict[key].min().drop(['p', 'q']),
                         'max': result_dict[key].max().drop(['p', 'q'])}
    t_stop_run_mc_pf = time.time()

    print(f"Power flows needed {t_stop_run_mc_pf - t_start_run_mc_pf} seconds")
    return result_dict, std_dict, t_stop_run_mc_pf - t_start_run_mc_pf


def df_to_mat(df, resolution):
    max_p = float(df['p'].max())
    min_p = float(df['p'].min())
    max_q = float(df['q'].max())
    min_q = float(df['q'].min())
    ax_p = np.arange(min_p, max_p + 1 * (max_p - min_p) / (resolution - 1), (max_p - min_p) / (resolution - 1))
    ax_q = np.arange(min_q, max_q + 1 * (max_q - min_q) / (resolution - 1), (max_q - min_q) / (resolution - 1))
    mat_feas = np.zeros((len(ax_q), len(ax_p)))
    mat_all = np.zeros((len(ax_q), len(ax_p)))
    for index, row in df.iterrows():
        idx, _ = find_value_close2list(ax_p, row['p'])
        jdx, _ = find_value_close2list(ax_q, row['q'])
        if row['flex']:
            idx, _ = find_value_close2list(ax_p, row['p'])
            jdx, _ = find_value_close2list(ax_q, row['q'])
            mat_feas[-1 - jdx, idx] += 1
        mat_all[-1 - jdx, idx] += 1
    return mat_feas, mat_all, ax_p, ax_q


def df_to_mat_tensor(df, resolution):
    max_p = float(df['p'].max())
    min_p = float(df['p'].min())
    max_q = float(df['q'].max())
    min_q = float(df['q'].min())
    ax_p = np.arange(min_p, max_p + 1 * (max_p - min_p) / (resolution - 1), (max_p - min_p) / (resolution - 1))
    ax_q = np.arange(min_q, max_q + 1 * (max_q - min_q) / (resolution - 1), (max_q - min_q) / (resolution - 1))
    mat_dict = {}
    for val in df.columns:
        if val not in ['p', 'q']:
            mat_dict[val] = np.zeros((len(ax_q), len(ax_p)))
    mat_dict['PQ'] = np.zeros((len(ax_q), len(ax_p)))
    for index, row in df.iterrows():
        idx, _ = find_value_close2list(ax_p, row['p'])
        jdx, _ = find_value_close2list(ax_q, row['q'])
        mat_dict['PQ'][jdx, idx] = 1
        for key in mat_dict:
            if key != 'PQ':
                mat_dict[key][jdx, idx] = row[key]
    return mat_dict, ax_p, ax_q


def df_to_mat_tensor2(df, resolution, init_pq):
    max_p = float(df['p'].max())
    min_p = float(df['p'].min())
    max_q = float(df['q'].max())
    min_q = float(df['q'].min())
    ax_p = np.arange(min_p, max_p + 1 * (max_p - min_p) / (resolution - 1), (max_p - min_p) / (resolution - 1))
    ax_q = np.arange(min_q, max_q + 1 * (max_q - min_q) / (resolution - 1), (max_q - min_q) / (resolution - 1))
    mat_dict = {}
    for val in df.columns:
        if val not in ['p', 'q']:
            mat_dict[val] = np.zeros((len(ax_q), len(ax_p)))
    mat_dict['PQ'] = np.zeros((len(ax_q), len(ax_p)))
    mat_dict['Dirac'] = np.zeros((len(ax_q), len(ax_p)))
    for index, row in df.iterrows():
        idx, _ = find_value_close2list(ax_p, row['p'])
        jdx, _ = find_value_close2list(ax_q, row['q'])
        mat_dict['PQ'][jdx, idx] = 1
        if abs(float(row['p']) - float(init_pq[0])) < 0.001 and abs(float(row['q']) - float(init_pq[1])) < 0.001:
            mat_dict['Dirac'][jdx, idx] = 1
        for key in mat_dict:
            if key not in ['PQ', 'Dirac']:
                mat_dict[key][jdx, idx] = row[key]
    return mat_dict, ax_p, ax_q


def df_to_mat_tensor_scaled(df, dp, dq):
    max_p = float(df['p'].max())
    min_p = float(df['p'].min())
    max_q = float(df['q'].max())
    min_q = float(df['q'].min())
    ax_p = np.arange(min_p, max_p + 1 * dp, dp)
    ax_q = np.arange(min_q, max_q + 1 * dq, dq)
    mat_dict = {}
    for val in df.columns:
        if val not in ['p', 'q']:
            mat_dict[val] = np.zeros((len(ax_q), len(ax_p)))
    mat_dict['PQ'] = np.zeros((len(ax_q), len(ax_p)))
    for index, row in df.iterrows():
        idx, _ = find_value_close2list(ax_p, row['p'])
        jdx, _ = find_value_close2list(ax_q, row['q'])
        mat_dict['PQ'][jdx, idx] = 1
        for key in mat_dict:
            if key not in ['PQ']:
                mat_dict[key][jdx, idx] = row[key]
    return mat_dict, ax_p, ax_q


def df_to_mat_tensor_scaled_and_init(df, dp, dq):
    max_p = float(df['p'].max())
    min_p = float(df['p'].min())
    max_q = float(df['q'].max())
    min_q = float(df['q'].min())
    ax_p = np.arange(min_p, max_p + 1 * dp, dp)
    ax_q = np.arange(min_q, max_q + 1 * dq, dq)
    mat_dict = {}
    for val in df.columns:
        if val not in ['p', 'q']:
            # mat_dict[val] = np.zeros((len(ax_q), len(ax_p)))
            mat_dict[val] = torch.zeros((len(ax_q), len(ax_p)))
    # mat_dict['PQ'] = np.zeros((len(ax_q), len(ax_p)))
    mat_dict['PQ'] = torch.zeros((len(ax_q), len(ax_p)))
    for index, row in df.iterrows():
        idx, _ = find_value_close2list(ax_p, row['p'])
        jdx, _ = find_value_close2list(ax_q, row['q'])
        mat_dict['PQ'][jdx, idx] = 1
        for key in mat_dict:
            if key not in ['PQ']:
                # mat_dict[key][jdx, idx] = np.float16(row[key])
                mat_dict[key][jdx, idx] = row[key]
    return mat_dict, ax_p, ax_q


def df_to_mat_tensor_torch(df, dp, dq):
    max_p = float(df['p'].max())
    min_p = float(df['p'].min())
    max_q = float(df['q'].max())
    min_q = float(df['q'].min())
    ax_p = np.arange(min_p, max_p + 1 * dp, dp)
    ax_q = np.arange(min_q, max_q + 1 * dq, dq)
    mat_dict = {}
    for val in df.columns:
        if val not in ['p', 'q']:
            mat_dict[val] = torch.zeros((len(ax_q), len(ax_p)))
    mat_dict['PQ'] = torch.zeros((len(ax_q), len(ax_p)))
    for index, row in df.iterrows():
        idx, _ = find_value_close2list(ax_p, row['p'])
        jdx, _ = find_value_close2list(ax_q, row['q'])
        mat_dict['PQ'][jdx, idx] = 1
        for key in mat_dict:
            if key not in ['PQ']:
                mat_dict[key][jdx, idx] = row[key]
    for key in mat_dict:
        mat_dict[key] = filter(mat_dict[key])
    return mat_dict, ax_p, ax_q


def df_to_mat_tensor_torchv2(df, dp, dq):
    max_p = float(df['p'].max())
    min_p = float(df['p'].min())
    max_q = float(df['q'].max())
    min_q = float(df['q'].min())
    ax_p = np.arange(min_p, max_p + 1 * dp, dp)
    ax_q = np.arange(min_q, max_q + 1 * dq, dq)
    mat_dict = {}
    tup = (-1, -1)
    for val in df.columns:
        if val not in ['p', 'q']:
            mat_dict[val] = torch.zeros((len(ax_q), len(ax_p)))
    mat_dict['PQ'] = torch.zeros((len(ax_q), len(ax_p)))
    for index, row in df.iterrows():
        idx, _ = find_value_close2list(ax_p, row['p'])
        jdx, _ = find_value_close2list(ax_q, row['q'])
        mat_dict['PQ'][jdx, idx] = 1
        for key in mat_dict:
            if key not in ['PQ']:
                mat_dict[key][jdx, idx] = row[key]
        if index == 0:
            tup = (jdx, idx)
    for key in mat_dict:
        mat_dict[key] = filter(mat_dict[key])
    return mat_dict, ax_p, ax_q, tup


def filter(mat):
    for i in range(len(mat) - 2):
        for j in range(len(mat[0]) - 2):
            if mat[i, j + 1] != 0 and mat[i + 1, j] != 0 and mat[i + 1, j + 2] != 0 and mat[i + 2, j + 1] != 0 and mat[
                i, j] == 0:
                mat[i + 1, j + 1] = (mat[i, j + 1] + mat[i + 1, j] + mat[i + 1, j + 2] + mat[i + 2, j + 1]) / 4
    return mat


def get_delta(df, dp, dq, init_pq):
    max_p = float(df['p'].max())
    min_p = float(df['p'].min())
    max_q = float(df['q'].max())
    min_q = float(df['q'].min())
    ax_p = np.arange(min_p, max_p + 1 * dp, dp)
    ax_q = np.arange(min_q, max_q + 1 * dq, dq)
    mat_list = []
    pq_mat = torch.zeros((len(ax_q), len(ax_p)))
    for index, row in df.iterrows():
        tmp_dict = {'dp': np.float16(row['p'] - init_pq[0]), 'dq': np.float16(row['q'] - init_pq[1])}
        idx, _ = find_value_close2list(ax_p, row['p'])
        jdx, _ = find_value_close2list(ax_q, row['q'])
        pq_mat[jdx, idx] = 1

        for val in df.columns:
            if val not in ['p', 'q']:
                tmp_dict[val] = np.float16(row[val])
        mat_list.append(tmp_dict)
    return mat_list, ax_p, ax_q, pq_mat


def df_to_tensor(df, dp, dq):
    max_p = tf.cast(df['p'].max(), tf.float32)
    min_p = tf.cast(df['p'].min(), tf.float32)
    max_q = tf.cast(df['q'].max(), tf.float32)
    min_q = tf.cast(df['q'].min(), tf.float32)
    ax_p = tf.range(min_p, max_p + 1 * dp, dp)
    ax_q = tf.range(min_q, max_q + 1 * dq, dq)
    mat_dict = {}
    for val in df.columns:
        if val not in ['p', 'q']:
            mat_dict[val] = tf.zeros((len(ax_q), len(ax_p)), dtype=tf.int32)
    mat_dict['PQ'] = tf.zeros((len(ax_q), len(ax_p)), dtype=tf.int32)
    jdx, _ = tf.unique(tf.cast(df['q'], tf.int32), out_idx=tf.int32)
    idx, _ = tf.unique(tf.cast(df['p'], tf.int32), out_idx=tf.int32)
    mat_dict['PQ'] = tf.tensor_scatter_nd_add(mat_dict['PQ'], tf.stack([jdx, idx], axis=-1),
                                              tf.ones_like(df['p'], dtype=tf.int32))
    for val in df.columns:
        if val not in ['p', 'q']:
            mat_dict[val] = tf.tensor_scatter_nd_add(mat_dict[val], tf.stack([jdx, idx], axis=-1),
                                                     tf.cast(df[val], tf.float16))
    return mat_dict, ax_p.cpu().numpy(), ax_q.cpu().numpy()


def profiles_to_mat(profiles, dp, dq, init_fsp_pq):
    prof = np.array(profiles)
    max_p = float(prof[:, 0].max() - init_fsp_pq[0])
    min_p = float(prof[:, 0].min() - init_fsp_pq[0])
    max_q = float(prof[:, 1].max() - init_fsp_pq[1])
    min_q = float(prof[:, 1].min() - init_fsp_pq[1])
    ax_p = np.arange(min_p, max_p + 1 * dp, dp)
    ax_q = np.arange(min_q, max_q + 1 * dq, dq)
    mat = np.zeros((len(ax_q), len(ax_p)))
    for index, row in enumerate(prof):
        idx, _ = find_value_close2list(ax_p, row[0] - init_fsp_pq[0])
        jdx, _ = find_value_close2list(ax_q, row[1] - init_fsp_pq[1])
        mat[jdx, idx] = 1
    return mat


def find_value_close2list(lst, voi):
    dist = np.inf
    idx = 0
    for i, value in enumerate(lst):
        if abs(value - voi) < dist:
            dist = abs(value - voi)
            idx = i
    return idx, lst[idx]


def update_conv_pqs(net, fsp_idx, fsp_type, profile):
    if fsp_type == 'Sgen':
        net.sgen['p_mw'][fsp_idx] = profile[0]
        net.sgen['q_mvar'][fsp_idx] = profile[1]
    else:
        net.load['p_mw'][fsp_idx] = profile[0]
        net.load['q_mvar'][fsp_idx] = profile[1]
    return net
