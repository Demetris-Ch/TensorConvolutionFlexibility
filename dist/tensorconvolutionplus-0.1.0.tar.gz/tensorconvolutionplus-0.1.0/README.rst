======
Usage
======

---------------
I. Reference
---------------

The TensorConvolution+ algorithm was published in IEEE Transactions on Smart Grid and can be read and referenced using:

[![DOI](https://doi.org/10.1109/TSG.2024.3453667)

Available at: https://ieeexplore.ieee.org/document/10663439

---------------------
II. Package
---------------------
The proposed package includes the functionalities to perform flexibility area estimation.

To install the package through a file, place the **tensorconvolutionplus-0.1.0.tar.gz** file in an accessible path and run:

.. code-block:: console

   (.venv) $ pip install path/to/package/tensorconvolutionplus-0.1.0.tar.gz

To install the package online (currently unavailable), run:

.. code-block:: console

   (.venv) $ pip install tensorconvolutionplus

To use the package, example python lines for each function can be:

.. code-block:: console

    from TensorConvolutionPlus import FA_Estimator as TCP

    TCP.exhaustive_pf(net_name='MV Oberrhein0', dp=0.15, dq=0.3, fsp_load_indices=[1, 2, 3], fsp_dg_indices=[1, 2, 3])

    TCP.monte_carlo_pf(net_name='MV Oberrhein0', no_samples=6000, fsp_load_indices=[1, 2, 3], fsp_dg_indices=[1, 2, 3])

    TCP.opf(net_name='CIGRE MV', opf_step=0.1, fsp_load_indices=[3, 5, 8], fsp_dg_indices=[8])

    TCP.tc_plus(net_name='MV Oberrhein0', fsp_load_indices=[1, 2, 3], dp=0.05, dq=0.1, fsp_dg_indices=[1, 2, 3])


    TCP.tc_plus_merge(net_name='MV Oberrhein0', fsp_load_indices=[1, 2, 3, 4], dp=0.05, dq=0.1, fsp_dg_indices=[1, 2, 3],
                      max_fsps=6)

    TCP.tc_plus_save_tensors(net_name='MV Oberrhein0', fsp_load_indices=[1, 2, 3], dp=0.05, dq=0.1, fsp_dg_indices=[1, 2, 3])

    # Importing the 'MV Oberrhein0' network as net (see tests.examples.py)
    # Fixing the network scaling and switches (see tests.examples.py)
    # Modifying its operating conditions (see tests.examples.py)
    import pandapower.networks as pn
    import pandapower as pp
    ...
    ...
    TCP.tc_plus_adapt(net=net, fsp_load_indices=fsp_load_indices, fsp_dg_indices=fsp_dg_indices)


Main functionalities include:

#. TensorConvolution+, estimating FAs using the TensorConvolution+ algorithm. In the current version, the estimations can vary in:
    - Pandapower network (names) for MV Oberrhein0, MV Oberrhein1, Cigre MV. If another network is in similar format as these pandapower networks, it can also be an input instead.
    - Resolutions for the discretization of the flexibility resources.
    - Network voltage and loading constraints.
    - Voltage and loading sensitivity thresholds.
    - Including/Excluding FSPs only offering full output reductions, or limited setpoints ( including these FSPs currently uses the numpy library and not pytorch).
    - Flexibility service providers.
    - Network structure and initial operating conditions.
    - Shape of flexibility resources. Currently FSP limits are:
        - the output cannot exceed the maximum apparent power of the FSP (resulting in a semi-oval shape),
        - the output P cannot exceed the maximum apparent power of the FSP, the output |Q| cannot exceed the maximum apparent power of the FSP (resulting in rectangular shape).
        - additional shapes can be adopted by modifying the sample generation function (not impacting the TensorConvolution+ aggregation).

#. TensorConvolution+, while storing estimated tensors and other useful information to adapt flexibility areas for different operating conditions. In the current version, the estimations can vary in:
    - Pandapower network (names) for MV Oberrhein0, MV Oberrhein1, Cigre MV. If another network is in similar format as these pandapower networks, it can also be an input instead.
    - Resolutions for the discretization of the flexibility resources.
    - Network voltage and loading constraints.
    - Voltage and loading sensitivity thresholds.
    - Flexibility service providers.
    - Network structure and initial operating conditions.
    - Shape of flexibility resources. Currently FSP limits are:
        - the output cannot exceed the maximum apparent power of the FSP (resulting in a semi-oval shape),
        - the output P cannot exceed the maximum apparent power of the FSP, the output |Q| cannot exceed the maximum apparent power of the FSP (resulting in rectangular shape).
        - additional shapes can be adopted by modifying the sample generation function (not impacting the TensorConvolution+ aggregation).

#. TensorConvolution+, while loading previously estimated tensors and other useful information to adapt flexibility areas from prior different operating conditions. In the current version, the estimations can vary in:
    - Pandapower network (names) for MV Oberrhein0, MV Oberrhein1, Cigre MV. If another network is in similar format as these pandapower networks, it can also be an input instead. The network must be the same as the stored one.
    - Resolutions for the discretization of the flexibility resources. Must be the same as the stored simulation.
    - Network voltage and loading constraints.
    - Flexibility service providers.  Must be the same as the stored simulation.
    - Network structure and initial operating conditions.
    - Shape of flexibility resources.  Must be the same as the stored simulation.

#. Monte Carlo power flow based flexibility area estimation. In the current version, the estimations can vary in:
    - Pandapower network (names) for MV Oberrhein0, MV Oberrhein1, Cigre MV. If another network is in similar format as these pandapower networks, it can also be an input instead.
    - Network voltage and loading constraints.
    - Number of samples.
    - Distribution used for samples, including:
        - 'Hard': Exploring the limit from each resource flexibility.
        - 'Uniform': Applying uniform distribution.
        - 'Kumaraswamy': Applying the Kumaraswamy distribution.
    - Flexibility service providers.
    - Including/Excluding FSPs only offering full output reductions, or limited setpoints (including these FSPs currently uses the numpy library and not pytorch).
    - Network structure and initial operating conditions.

#. Exhaustive power flow based flexibility area estimation. In the current version, the estimations can vary in:
    - Pandapower network (names) for MV Oberrhein0, MV Oberrhein1, Cigre MV. If another network is in similar format as these pandapower networks, it can also be an input instead.
    - Network voltage and loading constraints.
    - Resolutions for the discretization of the flexibility resources.
    - Flexibility service providers.
    - Including/Excluding FSPs only offering full output reductions, or limited setpoints (including these FSPs currently uses the numpy library and not pytorch).
    - Network structure and initial operating conditions.

#. Optimal power flow based flexibility area estimation. In the current version, the estimations can vary in:
    - Pandapower network. Cigre MV in radial structure converges whereas alternative networks might fail to converge.
    - Network voltage and loading constraints. Transformer loading is excluded due to convergence issues.
    - Flexibility service providers.
    - Network structure and initial operating conditions.


.. _installation:

------------------
III. Installation
------------------

To use TensorConvolution+, first install all dependencies using pip:

.. code-block:: console

   (.venv) $ pip install requirements.txt


---------------------
IV. Running Scenarios
---------------------

To run use case scenarios, you can use the json files under the ``scenarios`` folder:

IV.A) Accuracy in Population Estimation
---------------------------------------

The scenario for the journal's use case included:

#.  The **BruteForce_Ob0.json** file, by running: ``python src/ScriptsForJournal/main.py UC1/BruteForce_Ob0``
#.  The **TensorConv_Ob0.json** file, by running: ``python src/ScriptsForJournal/main.py UC1/TensorConv_Ob0``
#.  The **Compare_Ob0.json** file, by running: ``python src/ScriptsForJournal/main.py UC1/Compare_Ob0``

The first json file runs the Brute Force PF-based results, the second file runs the TensorConvolution+ algorithm to
generate the results. The third file compares the results, creates the population figure for the Brute Force, and
prints the estimated MSE.

If needed to avoid re-estimating the FAs, the results from the first two json files are in the **csv_results/UC1** folder.

In that case, to re-estimate the accuracy you can simply run:

#.  The **Compare_Ob0.json** file, by running: ``python src/ScriptsForJournal/main.py UC1/Compare_Ob0``

Example figures generated for these scenarios are in the folder **plots/UC1**

.. image:: //../plots/UC1/Compare_Flexibility_area_BruteOb0_2.svg
  :width: 400
.. image:: //../plots/UC1/Conv_multi_Conv_Conv_Brute_Ob0_2.svg
  :width: 400

IV.B) Speed and Range Accuracy
---------------------------------
The scenario for the journal's use case included:

The CSV results are under **csv_results/UC2**
To re-estimate the Average Accuracy and Create the Plots:

#.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_UC2_Plot``,

The figures are saved under **plots/UC2**

.. image:: //../plots/UC2/Loop/Kumaraswamy_MC_Oberrhein0_4FSPs_20_8.svg
  :width: 400
.. image:: //../plots/UC2/Loop/Uniform_MC_Oberrhein0_4FSPs_20_8.svg
  :width: 400
.. image:: //../plots/UC2/Loop/Hard_MC_Oberrhein0_4FSPs_20_8.svg
  :width: 400

**To run simulations:**



*For the Ob0 network:*

#.  For <No.FSP> in [2,3,4,5] and narrow voltage limitations:

    #.  Open the json file under **scenarios/UC2/Acc_Oberrhein0_UC2**.
    #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": 0, "FSPs": <No.FSP>, "no_scenarios": 20}``
    #.  Set the "name" to ``"MC Oberrhein0 <No.FSP>FSPs 20"``,
    #.  Set the "max_volt_pu" in "scenario_settings" to 1.05,
    #.  Set the "min_volt_pu" in "scenario_settings" to 0.95,
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein0_UC2``,

#.  For 6 FSPs (in different machines):

    #.  For <No.Ver> in [0,1,2,...19]:

        #.  Open the json file under **scenarios/UC2/Acc_Oberrhein0_UC2_FSP6**.
        #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": <No.Ver>, "FSPs": 6, "no_scenarios": 1, "Reduce": []}``
        #.  Set the "max_volt_pu" in "scenario_settings" to 1.05,
        #.  Set the "min_volt_pu" in "scenario_settings" to 0.95,
        #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein0_UC2_FSP6``,
        #.  If the simulation returned an error, add the <No.Ver> to the "Reduce" list and run ``main.py UC2/Acc_Oberrhein0_UC2_FSP6``,

#.  For 6 FSPs (using the same GPU of google Colab, and numpy version):

    #.  For <No.Ver> in [0,1,2,...19]:

        #.  Open the json file under **scenarios/UC2/Acc_Oberrhein0_UC2_FSP6**.
        #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": <No.Ver>, "FSPs": 6, "no_scenarios": 1, "Reduce": [2, 8, 9, 10, 12, 13, 18]}``
        #.  Set the "max_volt_pu" in "scenario_settings" to 1.05,
        #.  Set the "min_volt_pu" in "scenario_settings" to 0.95,
        #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein0_UC2_FSP6``,

#.  For 7 FSPs (in different machines):

    #.  For <No.Ver> in [0,1,2,...19]:

        #.  Open the json file under **scenarios/UC2/Acc_Oberrhein0_UC2_FSP7**.
        #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": <No.Ver>, "FSPs": 7, "no_scenarios": 1, "Reduce": []}``
        #.  Set the "max_volt_pu" in "scenario_settings" to 1.05,
        #.  Set the "min_volt_pu" in "scenario_settings" to 0.95,
        #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein0_UC2_FSP7``,
        #.  If the simulation returned an error, add the <No.Ver> to the "Reduce" list and run ``main.py UC2/Acc_Oberrhein0_UC2_FSP7``,

#.  For 7 FSPs (using the same GPU of google Colab, and numpy version):

    #.  For <No.Ver> in [0,1,2,...19]:

        #.  Open the json file under **scenarios/UC2/Acc_Oberrhein0_UC2_FSP7**.
        #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": <No.Ver>, "FSPs": 7, "no_scenarios": 1, "Reduce": [1, 2, 4, 6, 7, 8, 9, 10, 11, 12, 13, 16, 17, 18, 19]}``
        #.  Set the "max_volt_pu" in "scenario_settings" to 1.05,
        #.  Set the "min_volt_pu" in "scenario_settings" to 0.95,
        #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein0_UC2_FSP7``,


.. image:: //../plots/UC2/Oberrhein0_speed_log.svg
  :width: 400


#.  For <No.FSP> in [10,12,14] and wide voltage limitations:

    #.  Open the json file under **scenarios/UC2/Acc_Oberrhein0_UC2**.
    #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": 0, "FSPs": <No.FSP>, "no_scenarios": 20}``
    #.  Set the "name" to ``"MC Oberrhein0 <No.FSP>FSPs 20"``,
    #.  Set the "max_volt_pu" in "scenario_settings" to 1.1,
    #.  Set the "min_volt_pu" in "scenario_settings" to 0.9,
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein0_UC2``,


.. image:: //../plots/UC2/Oberrhein0W_speed_log.svg
  :width: 400


*For the Ob1 network:*
#.  For No.FSP in [2,3,4,5]:

    #.  Open the json file under **scenarios/UC2/Acc_Oberrhein1_UC2**.
    #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": 0, "FSPs": <No.FSP>, "no_scenarios": 20}``
    #.  Set the "name" to ``"MC Oberrhein1 <No.FSP>FSPs 20"``,
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein1_UC2``,

#.  For 6 FSPs (in different machines):

    #.  For <No.Ver> in [0,1,2,...19]:

        #.  Open the json file under **scenarios/UC2/Acc_Oberrhein1_UC2_FSP6**.
        #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": <No.Ver>, "FSPs": 6, "no_scenarios": 1, "Reduce": []}``
        #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein1_UC2_FSP6``,
        #.  If the simulation returned an error, add the <No.Ver> to the "Reduce" list and run ``main.py UC2/Acc_Oberrhein1_UC2_FSP6``,

#.  For 6 FSPs (using the same GPU of google Colab, and numpy version):

    #.  For <No.Ver> in [0,1,2,...19]:

        #.  Open the json file under **scenarios/UC2/Acc_Oberrhein1_UC2_FSP6**.
        #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": <No.Ver>, "FSPs": 6, "no_scenarios": 1, "Reduce": []}``
        #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein1_UC2_FSP6``,

#.  For 7 FSPs (in different machines):

    #.  For <No.Ver> in [0,1,2,...19]:

        #.  Open the json file under **scenarios/UC2/Acc_Oberrhein1_UC2_FSP7**.
        #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": <No.Ver>, "FSPs": 7, "no_scenarios": 1, "Reduce": []}``
        #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein1_UC2_FSP7``,
        #.  If the simulation returned an error, add the <No.Ver> to the "Reduce" list and run ``main.py UC2/Acc_Oberrhein1_UC2_FSP7``,

#.  For 7 FSPs (using the same GPU of google Colab, and numpy version):

    #.  For <No.Ver> in [0,1,2,...19]:

        #.  Open the json file under **scenarios/UC2/Acc_Oberrhein1_UC2_FSP7**.
        #.  On the UseCase list of the Scenario settings set:  ``{"No.": 3, "Ver.": <No.Ver>, "FSPs": 7, "no_scenarios": 1, "Reduce": []}``
        #.  Run: ``python src/ScriptsForJournal/main.py UC2/Acc_Oberrhein1_UC2_FSP7``,

.. image:: //../plots/UC2/Oberrhein1_speed_log.svg
  :width: 400

For a CI scenario, run:
#.  Run: ``python src/ScriptsForJournal/main.py UC2/LargeRadial``,


.. image:: //../plots/UC2/Conv_multi_Conv_LargeRadial.svg
  :width: 400

IV.C) Disjoint Flexibility Areas
---------------------------------
The scenario for the journal's use case included:

#.  The **MC_Discontinuous.json** file, by running: ``python src/ScriptsForJournal/main.py UC3/MC_Discontinuous``
#.  The **Conv_Discontinuous.json** file, by running: ``python src/ScriptsForJournal/main.py UC3/Conv_Discontinuous``

The first json file runs the PF-based results, the second file runs the TensorConvolution+ algorithm to
generate the results.

If needed to avoid re-estimating the FAs, the results from the first two json files are in the **csv_results/UC3** folder.

Example figures generated for these scenarios are in the folder **plots/UC3**

.. image:: //../plots/UC3/Disc_Scenario_121416012388_incl_infeasible.svg
  :width: 400
.. image:: //../plots/UC3/Conv_multi_Conv_Conv_Discontinuous.svg
  :width: 400

IV.D) Uncertainty Estimation for Small FSPs
-------------------------------------------
The scenario for the journal's use case included:

#.  The **Uncertainty_Conv.json** file, by running: ``python src/ScriptsForJournal/main.py UC4/Uncertainty_Conv``

The json file runs the TensorConvolution+ algorithm to
generate the results.

If needed to avoid re-estimating the FAs, the results are in the **csv_results/UC4** folder.

Example figure generated for the scenario is in the folder **plots/UC4**

.. image:: //../plots/UC4/Uncertainty_Interpreted.png
  :width: 400


IV.E) Adaptability
---------------------------------
The scenario for the journal's use case included:


#.  For the initial operating conditions of Ob0 (without saving tensors):

    #.  Open the json file under **scenarios/UC5/InitAdaptSaveOb0**.
    #.  On the Scenario settings set:  ``"save_tensors": false,``
    #.  Set the name to: ``"name": "UC5/NoSaveTsOb0",``
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/InitAdaptSaveOb0``,

#.  For the initial operating conditions of Ob0 (with saving tensors):

    #.  Open the json file under **scenarios/UC5/InitAdaptSaveOb0**.
    #.  On the Scenario settings set:  ``"save_tensors": true,``
    #.  Set the name to: ``"name": "UC5/SaveTsOb0",``
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/InitAdaptSaveOb0``,

#.  For the adapted operating conditions of Ob0 (without loading tensors):

    #.  Open the json file under **scenarios/UC5/ResAdaptOb0**.
    #.  On the Scenario settings set:  ``"adapt": false,``
    #.  Set the name to: ``"name": "UC5/NoLoadTsOb0",``
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/ResAdaptOb0``,

#.  For the adapted operating conditions of Ob0 (with loading tensors):

    #.  Open the json file under **scenarios/UC5/ResAdaptOb0**.
    #.  On the Scenario settings set:  ``"adapt": true,``
    #.  Set the name to: ``"name": "UC5/LoadTsOb0",``
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/ResAdaptOb0``,

Example results from the above files can be found in the **csv_results/UC5** folder.
Example plots, for the first two results are:

.. image:: //../plots/UC5/TCP_Conv_SaveTsOb0.svg
  :width: 400

The plots, for the 3rd results are:

.. image:: //../plots/UC5/TCP_Conv_NoLoadFlexOb0.svg
  :width: 400

The plots, for the 4th results are:

.. image:: //../plots/UC5/TCP_Conv_LoadFlexOb0.svg
  :width: 400

#.  For the initial operating conditions of CI (without saving tensors):

    #.  Open the json file under **scenarios/UC5/InitAdaptSave**.
    #.  On the Scenario settings set:  ``"save_tensors": false,``
    #.  Set the name to: ``"name": "UC5/NoSaveTs",``
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/InitAdaptSave``,

#.  For the initial operating conditions of CI (with saving tensors):

    #.  Open the json file under **scenarios/UC5/InitAdaptSave**.
    #.  On the Scenario settings set:  ``"save_tensors": true,``
    #.  Set the name to: ``"name": "UC5/SaveTs",``
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/InitAdaptSave``,

#.  For the adapted operating conditions of CI (without loading tensors):

    #.  Open the json file under **scenarios/UC5/ResAdapt**.
    #.  On the Scenario settings set:  ``"adapt": false,``
    #.  Set the name to: ``"name": "UC5/NoLoadTs",``
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/ResAdapt``,

#.  For the adapted operating conditions of CI (with loading tensors):

    #.  Open the json file under **scenarios/UC5/ResAdapt**.
    #.  On the Scenario settings set:  ``"adapt": true,``
    #.  Set the name to: ``"name": "UC5/LoadTs",``
    #.  Run: ``python src/ScriptsForJournal/main.py UC2/ResAdapt``,

Example results from the above files can be found in the **csv_results/UC5** folder.
Example plots, for the first two results are:

.. image:: //../plots/UC5/TCP_Conv_SaveFaTs.svg
  :width: 400

The plots, for the 3rd results are:

.. image:: //../plots/UC5/TCP_Conv_NoLoadTs_ax.svg
  :width: 400

Example plots, for the 4th results are:

.. image:: //../plots/UC5/TCP_Conv_LoadTs_ax.svg
  :width: 400


IV.F) Case study for DFC
-------------------------------------------
The scenario for the journal's use case included:

#.  The **Info.json** file, by running: ``python src/ScriptsForJournal/main.py UC6/Info``

The json file runs the TensorConvolution+ algorithm to
generate the results.

If needed to avoid re-estimating the FAs, the results are in the **csv_results/UC6** folder.

Example figures generated for the scenario are in the folder **plots/UC6**

.. image:: //../plots/UC6/feas_mat.svg
  :width: 250

.. image:: //../plots/UC6/heat_mat.svg
  :width: 250

.. image:: //../plots/UC6/min_cmat.svg
  :width: 250

.. image:: //../plots/UC6/nflex_mat.svg
  :width: 250

The json files run the TensorConvolution+ algorithm to
generate the results.


IV.G) Case study for OPFs
-------------------------------------------
The scenario for the journal's use case included:

For each of the dp, dq, opf_step specified in the journal:
    #.  Open the json file under **scenarios/UC7/TCP**.
    #.  On the Scenario settings set:  ``"dp": dp,``
    #.  On the Scenario settings set:  ``"dq": dq,``
    #.  On the Scenario settings set:  ``"opf_step": opf_step,``
    #.  Run: ``python src/ScriptsForJournal/main.py UC7/TCP``,

Example figure generated for this scenario is in the folder **plots/UC7**

.. image:: //../plots/UC7/OPF_.svg
  :width: 500

